package com.clucky.manage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageApplicationTests {

    @Test
    void contextLoads() {
        System.out.println(123);
    }

}
