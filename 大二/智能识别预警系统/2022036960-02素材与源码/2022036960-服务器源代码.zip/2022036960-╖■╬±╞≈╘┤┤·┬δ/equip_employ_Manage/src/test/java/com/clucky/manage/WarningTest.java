package com.clucky.manage;

import com.clucky.manage.domain.Warning;
import com.clucky.manage.service.WarningService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @Author: 程梁
 * @Date: 2022/05/01/12:48
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class WarningTest {

    @Autowired
    private WarningService warningService;

    @Test
    public void t1(){
        List<Warning> warningList = warningService.getAll();
        for (Warning warning : warningList) {
            System.out.println(warning);
        }
    }
}
