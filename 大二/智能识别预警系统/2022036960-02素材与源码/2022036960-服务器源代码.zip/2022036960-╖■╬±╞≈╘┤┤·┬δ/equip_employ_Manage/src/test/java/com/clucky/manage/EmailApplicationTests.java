package com.clucky.manage;

import com.clucky.manage.service.impl.EmailServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmailApplicationTests {

    @Autowired
    EmailServiceImpl emailService;

    @Test
    public void sendSimpleMailTest() {
        //调用定义的发送文本邮件的方法
        emailService.sendSimpleMail("2764700384@qq.com", "这是第一封邮件", "这是邮件内容");
    }
}
