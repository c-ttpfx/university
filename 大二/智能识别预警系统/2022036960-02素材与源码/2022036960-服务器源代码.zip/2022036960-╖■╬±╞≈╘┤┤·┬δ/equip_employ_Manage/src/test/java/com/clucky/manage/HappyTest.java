package com.clucky.manage;

/**
 * @Author: 程梁
 * @Date: 2022/04/30/0:22
 */
public class HappyTest {

    static class Girl{
        private String name = "杨幂";
        private String gender = "女";
        private int age = 18;
        private String describe = "我爱周益鑫，周益鑫最棒了";

        @Override
        public String toString() {
            return "姓名："+name+"\n性别："+gender+"\n年龄："+age+"\n想说的话："+describe;
        }
    }

    public static void main(String[] args) {
        Girl girl = new Girl();
        System.out.println(girl);
    }
}
