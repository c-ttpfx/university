package com.clucky.manage;

import com.clucky.manage.domain.EquipDayData;
import com.clucky.manage.service.IEmploySimplyService;
import com.clucky.manage.service.IEquipService;
import com.clucky.manage.service.ImgPathService;
import com.clucky.manage.service.impl.EmailServiceImpl;
import com.clucky.manage.utils.ImageUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ImageTest {

    @Autowired
    private ImgPathService imgPathService;
    @Test
    public void t1(){
        System.out.println("----------------------------------\n\n\n");
        String imgPath = ImageUtils.getImageRealPath();
        System.out.println(imgPath);
        System.out.println("\n\n\n----------------------------------");
    }

    @Test
    public void t2(){
        String path = imgPathService.getPathRealTimeById(1);
        System.out.println(path);
    }
}
