package com.clucky.manage;

import com.clucky.manage.domain.EquipDayData;
import com.clucky.manage.service.IEmploySimplyService;
import com.clucky.manage.service.IEquipService;
import com.clucky.manage.service.impl.EmailServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EquipTest {

    @Autowired
    private IEquipService equipService;
    @Test
    public void t1(){
        EquipDayData dayData = equipService.getDayData(1);
        System.out.println(dayData);
    }

    @Test
    public void t2(){
        List<EquipDayData> allDayDataAverage = equipService.getAllDayDataAverage();
        for (EquipDayData equipDayData : allDayDataAverage) {
            System.out.println(equipDayData);
        }
        System.out.println(allDayDataAverage.size());
    }
}
