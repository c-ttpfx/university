package com.clucky.manage.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.clucky.manage.domain.ImgPath;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @Author: 程梁
 * @Date: 2022/04/28/8:47
 */
public interface ImgPathService extends IService<ImgPath> {

    public String getPathRealTimeById(Integer id);

    public String getPathByTimeAndId(Integer id, Date date);
}
