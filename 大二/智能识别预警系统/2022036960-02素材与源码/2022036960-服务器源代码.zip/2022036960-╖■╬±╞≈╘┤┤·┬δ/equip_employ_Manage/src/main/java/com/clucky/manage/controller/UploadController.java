package com.clucky.manage.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.ClassUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

@Slf4j
@RestController
@RequestMapping
public class UploadController {

    @PostMapping("/upload")
    @ResponseBody
    public String upload(@RequestParam("image") MultipartFile uploadFile, @RequestParam("id") int id, HttpServletRequest request) throws UnsupportedEncodingException {
        ServletContext servletContext = request.getServletContext();
        servletContext.setAttribute("havaRealImage",true);
        if (id==2) {
            servletContext.setAttribute("havaPointRealImage", true);
        }

//        System.out.println(servletContext.getAttribute("havaRealImage"));
//        System.out.println(id);
        if (uploadFile.isEmpty()) {
            return "上传文件为空，请选择文件";
        }
        String fileName = uploadFile.getOriginalFilename();
//        String filePath = "C:/Users/14722/Desktop/"; //本地测试路径

        String path = ClassUtils.getDefaultClassLoader().getResource("static/table_image").getPath() + "/";
        path = URLDecoder.decode(path, "utf-8");

        File dest = new File(path + fileName);
        try {
            //使用组件上传
            uploadFile.transferTo(dest);
            log.info("文件:{},上传成功", fileName);
            return "上传成功!";
        } catch (IOException e) {
            log.error(e.toString(), e);
        }
        return "上传失败！";
    }
}