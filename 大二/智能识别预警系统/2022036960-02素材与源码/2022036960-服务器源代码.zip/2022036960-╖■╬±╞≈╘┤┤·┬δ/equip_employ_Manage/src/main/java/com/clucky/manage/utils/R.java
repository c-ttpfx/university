package com.clucky.manage.utils;

import lombok.Data;

/**
 * @Author: 程梁
 * @Date: 2021/12/21/15:37
 */
@Data
public class R {
    private boolean flag;
    private Object data;
    private String message;
    public R(boolean flag, Object data) {
        this.flag = flag;
        this.data = data;
    }

    public R() {
    }

    public R(boolean flag) {
        this.flag = flag;
    }

    public R(boolean flag, String message) {
        this.flag = flag;
        this.message = message;
    }
}
