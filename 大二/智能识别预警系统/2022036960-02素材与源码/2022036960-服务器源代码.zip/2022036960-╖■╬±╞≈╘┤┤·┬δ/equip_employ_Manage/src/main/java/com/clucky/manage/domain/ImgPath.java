package com.clucky.manage.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @Author: 程梁
 * @Date: 2022/04/28/8:43
 */
@Data
@TableName("img_path")
public class ImgPath {
    private Integer id;
    private Date time;
    private String path;
}
