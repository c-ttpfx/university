package com.clucky.manage.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.clucky.manage.domain.EmploySimply;
import com.clucky.manage.mapper.EmploySimplyMapper;
import com.clucky.manage.service.IEmploySimplyService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: 程梁
 * @Date: 2022/03/19/23:36
 */
@Service
public class EmploySimplyServiceImpl extends ServiceImpl<EmploySimplyMapper, EmploySimply> implements IEmploySimplyService {
    @Autowired
    private EmploySimplyMapper employSimplyMapper;
    @Override
    public boolean modify(EmploySimply employSimply) {
        return employSimplyMapper.updateById(employSimply) > 0;
    }

    @Override
    public boolean delete(int id) {
        return employSimplyMapper.deleteById(id) > 0;
    }

    @Override
    public Page<EmploySimply> page(int currentPage, int pageSize) {
        Page<EmploySimply> bookPage = new Page<>(currentPage, pageSize);
        return employSimplyMapper.selectPage(bookPage,null);
    }

    @Override
    public Page<EmploySimply> page(int currentPage, int pageSize, EmploySimply employSimply) {
        LambdaQueryWrapper<EmploySimply> lqw = new LambdaQueryWrapper<>();
        lqw.like(Strings.isNotEmpty(employSimply.getName()),EmploySimply::getName,employSimply.getName());
        lqw.like(employSimply.getAge()!=null,EmploySimply::getAge,employSimply.getAge());
        lqw.like(Strings.isNotEmpty(employSimply.getIdCard()),EmploySimply::getIdCard,employSimply.getIdCard());
        Page<EmploySimply> bookPage = new Page<>(currentPage, pageSize);
        return employSimplyMapper.selectPage(bookPage,lqw);
    }
}
