package com.clucky.manage.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.clucky.manage.domain.EmploySimply;

/**
 * @Author: 程梁
 * @Date: 2022/03/19/23:34
 */
public interface IEmploySimplyService extends IService<EmploySimply> {

    boolean modify(EmploySimply employSimply);

    boolean delete(int id);

    Page<EmploySimply> page(int currentPage, int pageSize);

    Page<EmploySimply> page(int currentPage, int pageSize, EmploySimply employSimply);

}
