package com.clucky.manage.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.clucky.manage.domain.ImgPath;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author: 程梁
 * @Date: 2022/04/28/8:46
 */
@Mapper
public interface ImgPathMapper extends BaseMapper<ImgPath> {
}
