package com.clucky.manage.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 程梁
 * @Date: 2022/05/08/1:31
 */
@RestController
@RequestMapping("/admin")
public class AdminController {

    @RequestMapping("/login")
    public String login(@RequestParam String username,@RequestParam String password){
        if ("admin".equals(username) && "admin".equals(password)){
            return "admin/index.html";
        }
        return "fail";
    }
}
