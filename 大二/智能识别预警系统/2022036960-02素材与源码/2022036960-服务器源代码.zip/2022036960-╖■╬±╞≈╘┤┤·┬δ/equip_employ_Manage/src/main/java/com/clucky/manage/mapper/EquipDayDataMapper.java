package com.clucky.manage.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.clucky.manage.domain.EquipDayData;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author: 程梁
 * @Date: 2022/04/16/18:48
 */
@Mapper
public interface EquipDayDataMapper extends BaseMapper<EquipDayData> {
}
