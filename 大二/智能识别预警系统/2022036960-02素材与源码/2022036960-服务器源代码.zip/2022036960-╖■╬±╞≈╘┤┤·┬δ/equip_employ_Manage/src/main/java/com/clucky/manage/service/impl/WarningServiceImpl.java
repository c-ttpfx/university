package com.clucky.manage.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.clucky.manage.domain.Warning;
import com.clucky.manage.mapper.WarningMapper;
import com.clucky.manage.service.WarningService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: 程梁
 * @Date: 2022/05/01/12:44
 */
@Service
public class WarningServiceImpl extends ServiceImpl<WarningMapper, Warning> implements WarningService {
    @Autowired
    private WarningMapper warningMapper;

    @Override
    public List<Warning> getAll(){
        return warningMapper.selectList(null);
    }
}
