package com.clucky.manage.controller;

import com.clucky.manage.service.EmailService;
import com.clucky.manage.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: 程梁
 * @Date: 2022/04/16/12:26
 */
@RestController
@RequestMapping("/sendEmail")
public class EmailController {
    @Autowired
    private EmailService emailService;

    @PostMapping
    public R send(@RequestParam String name, @RequestParam String title, @RequestParam String content) {
        try {
            emailService.sendSimpleMail(name,title,content);
        } catch (Exception e) {
            return new R(false,null);
        }
        return new R(true,null);
    }
}
