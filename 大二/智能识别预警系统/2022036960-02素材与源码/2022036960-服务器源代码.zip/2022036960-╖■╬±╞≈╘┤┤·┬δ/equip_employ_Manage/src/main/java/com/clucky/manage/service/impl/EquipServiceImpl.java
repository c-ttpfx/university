package com.clucky.manage.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.clucky.manage.domain.EquipDayData;
import com.clucky.manage.mapper.EquipDayDataMapper;
import com.clucky.manage.service.IEquipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: 程梁
 * @Date: 2022/03/19/23:36
 */
@Service
public class EquipServiceImpl extends ServiceImpl<EquipDayDataMapper, EquipDayData> implements IEquipService {

    @Autowired
    private EquipDayDataMapper equipDayDataMapper;

    @Override
    public EquipDayData getDayData(int id) {
        return equipDayDataMapper.selectById(id);
    }

    @Override
    public List<EquipDayData> getAllDayDataAverage() {
        List<EquipDayData> equipDayData = equipDayDataMapper.selectList(null);
        List<EquipDayData> equipDayDataList = new ArrayList<>();
        for (EquipDayData data : equipDayData) {
            double sum = data.getHour01() + data.getHour02() +
                    data.getHour03() + data.getHour04() + data.getHour05() +
                    data.getHour06() + data.getHour07() + data.getHour08() +
                    data.getHour09() + data.getHour10() + data.getHour11() +
                    data.getHour12() + data.getHour13() + data.getHour14() +
                    data.getHour15() + data.getHour16() + data.getHour17() +
                    data.getHour18() + data.getHour19() + data.getHour20() +
                    data.getHour21() + data.getHour22() + data.getHour23() +
                    data.getHour24();
            data.setDayDataAverage(Double.valueOf(String.format("%.2f", sum / 24)));
//            EquipDayData dayData = new EquipDayData();
//            dayData.setDayDataAverage(data.getDayDataAverage());
//            dayData.setId(data.getId());
//            dayData.setMeterId(data.getMeterId());
//            dayData.setDate(data.getDate());
//            dayData.setEmployeeId(data.getEmployeeId());
//            dayData.setPosition(data.getPosition());
            equipDayDataList.add(data);
            if (equipDayDataList.size() == 18)break;
        }
        return equipDayDataList;
    }
}
