package com.clucky.manage.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.beans.Transient;
import java.util.Date;

/**
 * @Author: 程梁
 * @Date: 2022/04/16/18:38
 */
@Data
@TableName("electricity_meterinfo")
public class EquipDayData {
    private Integer id;
    private String meterId;
    private String position;
    private String employeeId;
    private Date date;
    @TableField(exist = false)
    private Double dayDataAverage;
    private double hour01;
    private double hour02;
    private double hour03;
    private double hour04;
    private double hour05;
    private double hour06;
    private double hour07;
    private double hour08;
    private double hour09;
    private double hour10;
    private double hour11;
    private double hour12;
    private double hour13;
    private double hour14;
    private double hour15;
    private double hour16;
    private double hour17;
    private double hour18;
    private double hour19;
    private double hour20;
    private double hour21;
    private double hour22;
    private double hour23;
    private double hour24;



}
