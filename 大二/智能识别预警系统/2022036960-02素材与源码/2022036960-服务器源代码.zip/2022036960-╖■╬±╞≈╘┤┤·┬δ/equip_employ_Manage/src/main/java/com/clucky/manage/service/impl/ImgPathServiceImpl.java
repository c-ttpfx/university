package com.clucky.manage.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.clucky.manage.domain.ImgPath;
import com.clucky.manage.mapper.ImgPathMapper;
import com.clucky.manage.service.ImgPathService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @Author: 程梁
 * @Date: 2022/04/28/8:51
 */
@Service
public class ImgPathServiceImpl extends ServiceImpl<ImgPathMapper, ImgPath> implements ImgPathService {

    @Autowired
    private ImgPathMapper imgPathMapper;

    @Override
    public String getPathRealTimeById(Integer id) {
        ImgPath imgPath = imgPathMapper.selectById(id);
        return imgPath.getPath();
    }

    @Override
    public String getPathByTimeAndId(Integer id, Date date) {
        return null;
    }
}
