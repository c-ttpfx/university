package com.clucky.manage.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.clucky.manage.domain.Warning;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: 程梁
 * @Date: 2022/05/01/12:43
 */
public interface WarningService extends IService<Warning> {
    public List<Warning> getAll();
}
