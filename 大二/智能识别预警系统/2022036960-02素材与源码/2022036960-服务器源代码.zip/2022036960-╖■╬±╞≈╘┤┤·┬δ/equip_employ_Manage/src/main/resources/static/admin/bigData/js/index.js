var scn_data={
		alarm:{alarm:22,fault:5},
		dtu:{ on:12,off:5},
		plc:{on:8,off:2},
		industy:{v1:10,v2:11,v3:12,v3:14,v4:15,v5:17,v6:18},
		online:{v1:10,v2:11,v3:12,v3:14,v4:15,v5:17,v6:18},
		almMsg:[{msg:"2022年5月1日重庆市市A区12#机器气压过高报警"},
				{msg:"重庆市B区12机器温度异常报警"},
				{msg:"重庆市B区5#气压过高报警"},
				],
		msgCnt:[{msg:10,alm:2},
			{msg:20,alm:4},
			{msg:30,alm:5},
			{msg:40,alm:3},
			{msg:40,alm:4},
			{msg:40,alm:1},
			{msg:40,alm:6},
			{msg:10,alm:7},
			{msg:20,alm:8},
			{msg:30,alm:2},
			{msg:40,alm:9},
			{msg:40,alm:10},
			{msg:40,alm:11},
			{msg:40,alm:22},
			{msg:10,alm:33},
			{msg:20,alm:1},
			{msg:30,alm:3},
			{msg:40,alm:5},
			{msg:40,alm:7},
			{msg:40,alm:9}
			],
		map:[{area:"山东",cnt:20},
			{area:"浙江",cnt:40},
			{area:"江苏",cnt:50},
			{area:"辽宁",cnt:50}
		],
		factoryHeader:[
	        {"categories":"单位名"},
	        {"categories":"员工数"},
	        {"categories":"设备数"},
	        {"categories":"检测点"},
	        {"categories":"报警"},
	        {"categories":"操作"}
    	],
		factory:[
			{"company":"重庆A厂","dtuCnt": 30, "plcCnt": 16,"dataCnt": 8,"alarm": "气压异常阈值3500pa"},
	        {"company":"重庆B厂","dtuCnt": 40,"plcCnt": 8,"dataCnt": 10,"alarm": "温度上限报警>180"},
	        {"company":"重庆C厂","dtuCnt": 35,"plcCnt": 10,"dataCnt": 6,"alarm": "气压异常阈值3200pa"},
	        {"company":"重庆D厂","dtuCnt": 60,"plcCnt": 10,"dataCnt": 12,"alarm": "温度上限报警>120"},
	        {"company":"重庆E厂","dtuCnt": 50,"plcCnt": 7,"dataCnt": 13,"alarm": "流速<350m^3/s"},
	        {"company":"重庆F厂","dtuCnt": 46,"plcCnt": 12,"dataCnt": 5,"alarm": "流速<350m^3/s"},
		]
	};
var vm = new Vue({
	el: '#content',
	data: scn_data,
	methods: {
		details: function() {
			
		}
	}
})