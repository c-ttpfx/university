package com.clucky.manage.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @Author: 程梁
 * @Date: 2022/03/19/23:28
 */
@Data
public class EmploySimply {
    private Integer id;
    private String name;
    private String gender;
    private Integer age;
    private String idCard;


    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date joinTime;
    private Double salary;
}
