package com.clucky.manage.controller;

import com.clucky.manage.utils.ImageUtils;
import com.fasterxml.jackson.databind.util.ClassUtil;
import org.springframework.util.ClassUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Random;

/**
 * @Author: 程梁
 * @Date: 2022/04/25/9:39
 */
@RestController
@RequestMapping("/image")
public class ImageController {
    private final static String webPath = "http://localhost/table_image/";

    @RequestMapping("/realTimeImage")
    public String getRealTimeImage(HttpServletRequest request) throws UnsupportedEncodingException {

        ServletContext servletContext = request.getServletContext();
        Boolean havaRealImage = (Boolean) servletContext.getAttribute("havaRealImage");
        if (havaRealImage != null && havaRealImage) {
            int index = 1;
            String path = webPath + index + ".png";
            return path;
        } else {
            int index = new Random().nextInt(11);
            String path = "http://localhost/images/" + index + ".png";
            return path;
        }
    }

    @RequestMapping("/pointRealTimeImage")
    public String getPointRealTimeImage(HttpServletRequest request) throws UnsupportedEncodingException {

        ServletContext servletContext = request.getServletContext();
        Boolean havaPointRealImage = (Boolean) servletContext.getAttribute("havaPointRealImage");
        if (havaPointRealImage != null && havaPointRealImage) {
            int index = 2;
            String path = webPath + index + ".png";
            return path;
        } else {
            int index = new Random().nextInt(49);
            String path = "http://localhost/images/points/" + index + ".png";
            return path;
        }
    }
}
