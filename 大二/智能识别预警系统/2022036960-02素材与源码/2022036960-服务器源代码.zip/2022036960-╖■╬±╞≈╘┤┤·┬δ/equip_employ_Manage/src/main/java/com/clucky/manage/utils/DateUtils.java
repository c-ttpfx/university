package com.clucky.manage.utils;

import java.time.LocalDate;

/**
 * @Author: 程梁
 * @Date: 2022/03/30/12:49
 */
public class DateUtils {

    public static String getYearMonthDay(){
        LocalDate localDate = LocalDate.now();
        int year = localDate.getYear();
        int month = localDate.getMonthValue();
        int day = localDate.getDayOfMonth();
        return year+"/"+month+"/"+day;
    }

    public static void main(String[] args) {
        System.out.println(getYearMonthDay());
    }
}
