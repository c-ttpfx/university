package com.clucky.manage.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.clucky.manage.domain.EmploySimply;
import com.clucky.manage.service.IEmploySimplyService;
import com.clucky.manage.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: 程梁
 * @Date: 2021/12/21/14:44
 */
@RestController
@RequestMapping("/employSimply")
public class EmploySimplyController {
    @Autowired
    private IEmploySimplyService employSimplyService;

    @GetMapping
    public R findAll() {
        return new R(true, employSimplyService.list());
    }

    @PostMapping
    public R save(@RequestBody EmploySimply employSimply) {
        return new R(employSimplyService.save(employSimply));
    }

    @PutMapping
    public R update(@RequestBody EmploySimply employSimply) {
        return new R(employSimplyService.modify(employSimply));
    }

    @DeleteMapping("{id}")
    public R delete(@PathVariable Integer id) {
        return new R(employSimplyService.delete(id));
    }

    @GetMapping("{id}")
    public R getById(@PathVariable Integer id) {
        return new R(true, employSimplyService.getById(id));
    }

    @GetMapping("{currentPage}/{pageSize}")
    public R getPage(@PathVariable Integer currentPage, @PathVariable Integer pageSize, EmploySimply employSimply) {
        System.out.println(employSimply);

        Page<EmploySimply> employSimplyPage = employSimplyService.page(currentPage, pageSize, employSimply);
        if (employSimplyPage.getPages() < currentPage) {
            employSimplyPage = employSimplyService.page((int) employSimplyPage.getPages(), pageSize, employSimply);
        }
        return new R(true, employSimplyPage);
    }
}
