package com.clucky.manage.utils;

/**
 * @Author: 程梁
 * @Date: 2022/04/25/9:35
 */
public class ImageUtils {

    public static String getImageRealPath(){
        return ImageUtils.class.getClass().getResource("/").getPath();
    }
}
