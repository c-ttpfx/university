// 创建地图实例
var map = new BMapGL.Map('map_container');
var point = new BMapGL.Point(113.635198,34.773611);
map.centerAndZoom(point, 6);
map.enableScrollWheelZoom(true);  
//自定义地图样式
        
var styleJson =[{
  "featureType": "land",
  "elementType": "geometry",
  "stylers": {
      "color": "#fffff9ff"
  }
}, {
  "featureType": "water",
  "elementType": "geometry",
  "stylers": {
      "color": "#69b0acff"
  }
}, {
  "featureType": "highway",
  "elementType": "geometry.fill",
  "stylers": {
      "color": "#b5caa0ff"
  }
}, {
  "featureType": "highway",
  "elementType": "geometry.stroke",
  "stylers": {
      "color": "#94ad79ff"
  }
}, {
  "featureType": "nationalway",
  "elementType": "geometry.fill",
  "stylers": {
      "color": "#b5caa0ff"
  }
}, {
  "featureType": "arterial",
  "elementType": "geometry.fill",
  "stylers": {
      "color": "#d4e2c6ff"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "geometry.fill",
  "stylers": {
      "color": "#d4e2c6ff"
  }
}, {
  "featureType": "provincialway",
  "elementType": "geometry.fill",
  "stylers": {
      "color": "#d4e2c6ff"
  }
}, {
  "featureType": "provincialway",
  "elementType": "geometry.stroke",
  "stylers": {
      "color": "#b5caa0ff"
  }
}, {
  "featureType": "tertiaryway",
  "elementType": "geometry.fill",
  "stylers": {
      "color": "#ffffffff"
  }
}, {
  "featureType": "tertiaryway",
  "elementType": "geometry.stroke",
  "stylers": {
      "color": "#b5caa0ff"
  }
}, {
  "featureType": "fourlevelway",
  "elementType": "geometry.fill",
  "stylers": {
      "color": "#ffffffff"
  }
}, {
  "featureType": "fourlevelway",
  "elementType": "geometry.stroke",
  "stylers": {
      "color": "#b5caa0ff"
  }
}, {
  "featureType": "subway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "railway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "highwaysign",
  "elementType": "labels",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "highwaysign",
  "elementType": "labels.icon",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "nationalwaysign",
  "elementType": "labels",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "nationalwaysign",
  "elementType": "labels.icon",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "provincialwaysign",
  "elementType": "labels",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "provincialwaysign",
  "elementType": "labels.icon",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "tertiarywaysign",
  "elementType": "labels",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "tertiarywaysign",
  "elementType": "labels.icon",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "subwaylabel",
  "elementType": "labels",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "subwaylabel",
  "elementType": "labels.icon",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "nationalway",
  "elementType": "geometry.stroke",
  "stylers": {
      "color": "#94ad79ff"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "geometry.stroke",
  "stylers": {
      "color": "#b5caa0ff"
  }
}, {
  "featureType": "arterial",
  "elementType": "geometry.stroke",
  "stylers": {
      "color": "#b5caa0ff"
  }
}, {
  "featureType": "highway",
  "stylers": {
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "stylers": {
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "stylers": {
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "stylers": {
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "highway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "stylers": {
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "stylers": {
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "stylers": {
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "stylers": {
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "nationalway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "provincialway",
  "stylers": {
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "8-9"
  }
}, {
  "featureType": "provincialway",
  "stylers": {
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "8-9"
  }
}, {
  "featureType": "provincialway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "8-9"
  }
}, {
  "featureType": "provincialway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "8-9"
  }
}, {
  "featureType": "provincialway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "8-9"
  }
}, {
  "featureType": "provincialway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "8-9"
  }
}, {
  "featureType": "cityhighway",
  "stylers": {
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "stylers": {
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "stylers": {
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "stylers": {
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "geometry",
  "stylers": {
      "visibility": "off",
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "6",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "7",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "8",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "cityhighway",
  "elementType": "labels",
  "stylers": {
      "visibility": "off",
      "level": "9",
      "curZoomRegionId": "0",
      "curZoomRegion": "6-9"
  }
}, {
  "featureType": "entertainment",
  "elementType": "geometry",
  "stylers": {
      "color": "#e4f0d7ff"
  }
}, {
  "featureType": "manmade",
  "elementType": "geometry",
  "stylers": {
      "color": "#effcf0ff"
  }
}, {
  "featureType": "education",
  "elementType": "geometry",
  "stylers": {
      "color": "#e3f7e4ff"
  }
}, {
  "featureType": "building",
  "elementType": "geometry.stroke",
  "stylers": {
      "color": "#a1cfa4ff"
  }
}, {
  "featureType": "poilabel",
  "elementType": "labels",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "poilabel",
  "elementType": "labels.icon",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "education",
  "elementType": "labels.text.fill",
  "stylers": {
      "color": "#7a7a7aff"
  }
}, {
  "featureType": "education",
  "elementType": "labels.text.stroke",
  "stylers": {
      "color": "#ffffffff"
  }
}, {
  "featureType": "education",
  "elementType": "labels.text",
  "stylers": {
      "fontsize": "26"
  }
}, {
  "featureType": "manmade",
  "elementType": "labels.text.fill",
  "stylers": {
      "color": "#afafafff"
  }
}, {
  "featureType": "manmade",
  "elementType": "labels.text",
  "stylers": {
      "fontsize": "26"
  }
}, {
  "featureType": "scenicspotslabel",
  "elementType": "labels.text.fill",
  "stylers": {
      "color": "#376b6dff"
  }
}, {
  "featureType": "scenicspots",
  "elementType": "labels",
  "stylers": {
      "visibility": "off"
  }
}, {
  "featureType": "scenicspotslabel",
  "elementType": "labels",
  "stylers": {
      "visibility": "on"
  }
}, {
  "featureType": "scenicspotslabel",
  "elementType": "labels.text.stroke",
  "stylers": {
      "color": "#ffffffff",
      "weight": "4"
  }
}, {
  "featureType": "country",
  "elementType": "labels.text.fill",
  "stylers": {
      "color": "#376b6dff"
  }
}, {
  "featureType": "country",
  "elementType": "labels.text.stroke",
  "stylers": {
      "color": "#ffffffff",
      "weight": "3"
  }
}, {
  "featureType": "water",
  "elementType": "labels.text.fill",
  "stylers": {
      "color": "#ffffffff"
  }
}, {
  "featureType": "water",
  "elementType": "labels.text.stroke",
  "stylers": {
      "color": "#ffffff00"
  }
}, {
  "featureType": "water",
  "elementType": "labels.text",
  "stylers": {
      "fontsize": "24"
  }
}, {
  "featureType": "city",
  "elementType": "labels",
  "stylers": {
      "visibility": "on"
  }
}];
map.setMapStyleV2({     
  styleJson: styleJson
});

//创建MapVGL图层管理器
var view = new mapvgl.View({
    map: map
});
//创建数据可视化
var citys = [
    '重庆'
];
var Test = [
   6
];
var Test1 = [
    6
];

var data = [];

for (var i = 0; i < citys.length; i++) {
    var cityName = citys[i];
    var cityCenter = mapv.utilCityCenter.getCenterByCityName(citys[i]);
    data.push({
        geometry: {
            type: 'Point',
            coordinates: [cityCenter.lng, cityCenter.lat]
        },
        properties: {
            text: cityName + '\t' + Test[i]+'\n' + Test1[i],
        },
    });
}


var layer = new mapvgl.PointLayer({
    color: 'rgba(238, 44, 44, 0.8)',
    shape: 'circle', // 默认为圆形，可传square改为正方形
    blend: 'lighter',
    size: 12,
    enablePicked: true, // 是否可以拾取
    selectedIndex: -1, // 选中项
    selectedColor: '#CD5555', // 选中项颜色
    autoSelect: true, // 根据鼠标位置来自动设置选中项
    onClick: (e) => { // 点击事件
        console.log('click', e);
    }         
});
var Labellayer = new mapvgl.LabelLayer({
    textAlign: 'center',
    textColor: '#fc0',
    borderColor: '#666',
    backgroundColor: '#666',
    padding: [2, 5],
    borderRadius: 5,
    fontSize: 12,
    lineHeight: 16,
    collides: true, // 是否开启碰撞检测, 数量较多时建议打开
    enablePicked: true,
    onClick: e => {
        // 点击事件
        console.log('click', e);
    },
});

view.addLayer(layer);
layer.setData(data);
view.addLayer(Labellayer);      
Labellayer.setData(data);