package com.clucky.manage.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.clucky.manage.domain.EquipDayData;

import java.util.List;

/**
 * @Author: 程梁
 * @Date: 2022/04/16/18:36
 */
public interface IEquipService extends IService<EquipDayData> {

    public EquipDayData getDayData(int id);

    public List<EquipDayData> getAllDayDataAverage();
}
