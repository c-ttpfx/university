package com.clucky.manage.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.clucky.manage.domain.Warning;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author: 程梁
 * @Date: 2022/05/01/12:42
 */
@Mapper
public interface WarningMapper extends BaseMapper<Warning> {
}
