package com.clucky.manage.controller;

import com.clucky.manage.domain.EquipDayData;
import com.clucky.manage.domain.Warning;
import com.clucky.manage.service.IEquipService;
import com.clucky.manage.service.WarningService;
import com.clucky.manage.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author: 程梁
 * @Date: 2022/04/16/20:14
 */
@RestController
@RequestMapping("/equip")
public class EquipController {
    @Autowired
    private IEquipService equipService;
    @Autowired
    private WarningService warningService;

    @RequestMapping("/dayData")
    public R getDayData(@RequestParam int id) {
        EquipDayData dayData = equipService.getDayData(id);
        return new R(true, dayData);
    }

    @RequestMapping("/allWarningRecords")
    public R getAllWarningRecords(){
        List<Warning> warningList = warningService.getAll();
        return new R(true,warningList);
    }

    @RequestMapping("allDayDataAverage")
    public R getAllDayDataAverage(){
        List<EquipDayData> allDayDataAverage = equipService.getAllDayDataAverage();
        return new R(true,allDayDataAverage);
    }
}
