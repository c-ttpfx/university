package com.clucky.manage.service;

/**
 * @Author: 程梁
 * @Date: 2022/04/16/13:34
 */
public interface EmailService {
    public void sendSimpleMail(String to, String subject, String content);
}
