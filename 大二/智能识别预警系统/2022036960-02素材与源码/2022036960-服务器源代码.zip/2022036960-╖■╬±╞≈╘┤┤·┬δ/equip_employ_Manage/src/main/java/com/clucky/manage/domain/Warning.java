package com.clucky.manage.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @Author: 程梁
 * @Date: 2022/05/01/12:40
 */
@Data
@TableName("warnings")
public class Warning {
    private Integer id;
    private Date date;
    private String MeterId;
    private String position;
    private String reason;
    private String employeeId;
}
