package com.clucky.manage.utils;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @Author: 程梁
 * @Date: 2021/12/31/1:01
 */
//@ControllerAdvice
@RestControllerAdvice
public class ProjectExceptionAdvice {

    @ExceptionHandler
    public R doException(Exception e){
        e.printStackTrace();
        return new R(false,"请稍后再试");
    }
}
