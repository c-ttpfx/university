/*
 Navicat Premium Data Transfer

 Source Server         : study
 Source Server Type    : MySQL
 Source Server Version : 50719
 Source Host           : localhost:3306
 Source Schema         : equip_employ_manage

 Target Server Type    : MySQL
 Target Server Version : 50719
 File Encoding         : 65001

 Date: 08/05/2022 19:36:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for electricity_meterinfo
-- ----------------------------
DROP TABLE IF EXISTS `electricity_meterinfo`;
CREATE TABLE `electricity_meterinfo`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `meter_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `position` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `employee_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `date` date NULL DEFAULT NULL,
  `hour01` int(11) NULL DEFAULT NULL,
  `hour02` int(11) NULL DEFAULT NULL,
  `hour03` int(11) NULL DEFAULT NULL,
  `hour04` int(11) NULL DEFAULT NULL,
  `hour05` int(11) NULL DEFAULT NULL,
  `hour06` int(11) NULL DEFAULT NULL,
  `hour07` int(11) NULL DEFAULT NULL,
  `hour08` int(11) NULL DEFAULT NULL,
  `hour09` int(11) NULL DEFAULT NULL,
  `hour10` int(11) NULL DEFAULT NULL,
  `hour11` int(11) NULL DEFAULT NULL,
  `hour12` int(11) NULL DEFAULT NULL,
  `hour13` int(11) NULL DEFAULT NULL,
  `hour14` int(11) NULL DEFAULT NULL,
  `hour15` int(11) NULL DEFAULT NULL,
  `hour16` int(11) NULL DEFAULT NULL,
  `hour17` int(11) NULL DEFAULT NULL,
  `hour18` int(11) NULL DEFAULT NULL,
  `hour19` int(11) NULL DEFAULT NULL,
  `hour20` int(11) NULL DEFAULT NULL,
  `hour21` int(11) NULL DEFAULT NULL,
  `hour22` int(11) NULL DEFAULT NULL,
  `hour23` int(11) NULL DEFAULT NULL,
  `hour24` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 201 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of electricity_meterinfo
-- ----------------------------
INSERT INTO `electricity_meterinfo` VALUES (1, 'meter0', '位置0', 'worker1', '2022-04-23', 23, 22, 22, 27, 29, 25, 42, 40, 48, 51, 34, 28, 28, 28, 28, 29, 50, 54, 52, 48, 31, 25, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (2, 'meter1', '位置1', 'worker1', '2022-04-23', 23, 21, 24, 25, 26, 26, 40, 43, 48, 50, 33, 26, 28, 29, 28, 27, 54, 54, 51, 45, 31, 25, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (3, 'meter2', '位置2', 'worker1', '2022-04-23', 24, 25, 25, 27, 29, 27, 41, 43, 46, 53, 32, 29, 29, 29, 28, 25, 51, 51, 50, 48, 33, 26, 26, 29);
INSERT INTO `electricity_meterinfo` VALUES (4, 'meter3', '位置3', 'worker1', '2022-04-23', 21, 23, 23, 26, 27, 27, 44, 41, 48, 54, 34, 29, 26, 28, 28, 26, 52, 54, 53, 49, 31, 25, 27, 27);
INSERT INTO `electricity_meterinfo` VALUES (5, 'meter4', '位置4', 'worker1', '2022-04-23', 20, 21, 23, 29, 25, 29, 43, 44, 47, 50, 30, 28, 25, 25, 27, 29, 54, 52, 51, 45, 33, 25, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (6, 'meter5', '位置5', 'worker1', '2022-04-23', 24, 22, 22, 27, 28, 28, 40, 40, 49, 53, 34, 26, 26, 29, 26, 26, 50, 53, 54, 48, 32, 28, 27, 26);
INSERT INTO `electricity_meterinfo` VALUES (7, 'meter6', '位置6', 'worker1', '2022-04-23', 24, 21, 24, 25, 27, 27, 41, 42, 49, 51, 34, 25, 26, 25, 26, 26, 52, 54, 50, 47, 31, 26, 28, 29);
INSERT INTO `electricity_meterinfo` VALUES (8, 'meter7', '位置7', 'worker1', '2022-04-23', 20, 23, 24, 28, 27, 27, 44, 40, 46, 52, 31, 27, 29, 25, 26, 26, 51, 53, 54, 46, 32, 25, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (9, 'meter8', '位置8', 'worker1', '2022-04-23', 22, 23, 25, 26, 27, 29, 44, 41, 48, 53, 34, 27, 28, 25, 26, 28, 50, 53, 54, 46, 31, 27, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (10, 'meter9', '位置9', 'worker1', '2022-04-23', 24, 25, 26, 25, 27, 26, 41, 44, 46, 52, 33, 29, 26, 29, 26, 28, 54, 53, 51, 49, 34, 25, 26, 28);
INSERT INTO `electricity_meterinfo` VALUES (11, 'meter10', '位置10', 'worker1', '2022-04-23', 24, 23, 22, 26, 26, 28, 40, 44, 45, 54, 33, 26, 25, 26, 29, 28, 53, 54, 53, 46, 32, 26, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (12, 'meter11', '位置11', 'worker1', '2022-04-23', 23, 25, 23, 28, 27, 26, 40, 43, 45, 54, 32, 25, 28, 25, 29, 29, 50, 53, 50, 45, 32, 25, 28, 26);
INSERT INTO `electricity_meterinfo` VALUES (13, 'meter12', '位置12', 'worker1', '2022-04-23', 20, 24, 24, 27, 26, 27, 41, 40, 45, 53, 32, 28, 27, 29, 26, 27, 52, 50, 52, 46, 34, 29, 26, 28);
INSERT INTO `electricity_meterinfo` VALUES (14, 'meter13', '位置13', 'worker1', '2022-04-23', 20, 22, 23, 25, 28, 25, 44, 43, 49, 54, 33, 27, 29, 29, 26, 28, 54, 50, 52, 48, 34, 26, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (15, 'meter14', '位置14', 'worker1', '2022-04-23', 22, 24, 24, 25, 28, 26, 43, 43, 48, 52, 33, 27, 26, 28, 29, 25, 51, 51, 50, 46, 32, 28, 27, 26);
INSERT INTO `electricity_meterinfo` VALUES (16, 'meter15', '位置15', 'worker2', '2022-04-23', 24, 21, 24, 28, 29, 25, 43, 44, 47, 52, 33, 29, 25, 29, 29, 25, 50, 50, 52, 49, 33, 25, 28, 26);
INSERT INTO `electricity_meterinfo` VALUES (17, 'meter16', '位置16', 'worker2', '2022-04-23', 22, 23, 26, 27, 26, 27, 44, 40, 47, 54, 31, 28, 29, 28, 28, 28, 52, 54, 52, 48, 34, 28, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (18, 'meter17', '位置17', 'worker2', '2022-04-23', 21, 23, 23, 26, 28, 25, 43, 43, 46, 52, 33, 26, 29, 26, 27, 29, 54, 50, 54, 46, 30, 29, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (19, 'meter18', '位置18', 'worker2', '2022-04-23', 23, 22, 22, 28, 29, 28, 43, 40, 47, 54, 33, 26, 28, 25, 28, 25, 54, 54, 50, 46, 32, 25, 28, 29);
INSERT INTO `electricity_meterinfo` VALUES (20, 'meter19', '位置19', 'worker2', '2022-04-23', 23, 25, 24, 27, 28, 26, 43, 42, 49, 54, 34, 29, 29, 29, 25, 26, 51, 52, 51, 47, 30, 26, 29, 28);
INSERT INTO `electricity_meterinfo` VALUES (21, 'meter20', '位置20', 'worker2', '2022-04-23', 22, 22, 22, 25, 26, 29, 41, 43, 48, 52, 30, 26, 29, 29, 29, 28, 51, 53, 54, 47, 34, 29, 27, 25);
INSERT INTO `electricity_meterinfo` VALUES (22, 'meter21', '位置21', 'worker2', '2022-04-23', 22, 22, 23, 25, 28, 25, 40, 40, 46, 54, 33, 27, 26, 25, 25, 27, 52, 51, 52, 49, 33, 28, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (23, 'meter22', '位置22', 'worker2', '2022-04-23', 20, 21, 24, 28, 29, 25, 41, 40, 46, 54, 33, 25, 26, 29, 28, 26, 50, 54, 52, 45, 33, 26, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (24, 'meter23', '位置23', 'worker2', '2022-04-23', 21, 22, 23, 27, 29, 28, 42, 43, 47, 51, 33, 26, 26, 28, 28, 29, 53, 54, 53, 45, 33, 27, 27, 26);
INSERT INTO `electricity_meterinfo` VALUES (25, 'meter24', '位置24', 'worker2', '2022-04-23', 21, 24, 25, 29, 27, 25, 43, 44, 46, 54, 31, 26, 29, 29, 25, 27, 52, 53, 53, 45, 31, 27, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (26, 'meter25', '位置25', 'worker2', '2022-04-23', 24, 25, 25, 25, 27, 27, 41, 42, 47, 51, 33, 27, 28, 28, 25, 27, 52, 52, 54, 49, 33, 29, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (27, 'meter26', '位置26', 'worker2', '2022-04-23', 24, 23, 23, 29, 26, 25, 42, 44, 46, 51, 31, 27, 27, 26, 28, 27, 52, 52, 52, 48, 30, 26, 27, 27);
INSERT INTO `electricity_meterinfo` VALUES (28, 'meter27', '位置27', 'worker2', '2022-04-23', 20, 25, 26, 28, 28, 29, 40, 40, 47, 52, 31, 28, 26, 27, 27, 28, 51, 50, 50, 49, 32, 27, 29, 28);
INSERT INTO `electricity_meterinfo` VALUES (29, 'meter28', '位置28', 'worker2', '2022-04-23', 22, 25, 26, 29, 29, 27, 41, 41, 49, 51, 34, 28, 25, 27, 29, 27, 50, 51, 52, 47, 30, 25, 28, 26);
INSERT INTO `electricity_meterinfo` VALUES (30, 'meter29', '位置29', 'worker2', '2022-04-23', 23, 21, 22, 28, 28, 25, 44, 40, 45, 54, 31, 26, 25, 27, 27, 28, 52, 54, 51, 47, 30, 27, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (31, 'meter30', '位置30', 'worker3', '2022-04-23', 23, 24, 22, 28, 27, 26, 43, 40, 48, 53, 34, 29, 26, 25, 26, 25, 52, 53, 52, 45, 32, 26, 25, 27);
INSERT INTO `electricity_meterinfo` VALUES (32, 'meter31', '位置31', 'worker3', '2022-04-23', 24, 25, 22, 27, 27, 27, 44, 40, 47, 50, 31, 25, 25, 27, 25, 25, 52, 53, 50, 49, 32, 27, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (33, 'meter32', '位置32', 'worker3', '2022-04-23', 20, 23, 24, 26, 27, 28, 42, 43, 46, 54, 33, 26, 29, 28, 27, 27, 52, 52, 50, 47, 31, 29, 29, 25);
INSERT INTO `electricity_meterinfo` VALUES (34, 'meter33', '位置33', 'worker3', '2022-04-23', 22, 24, 26, 25, 28, 27, 40, 41, 49, 51, 31, 27, 28, 29, 25, 25, 53, 54, 53, 46, 32, 26, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (35, 'meter34', '位置34', 'worker3', '2022-04-23', 24, 22, 25, 25, 25, 25, 44, 41, 48, 51, 33, 27, 25, 28, 28, 27, 54, 54, 54, 48, 32, 29, 26, 29);
INSERT INTO `electricity_meterinfo` VALUES (36, 'meter35', '位置35', 'worker3', '2022-04-23', 22, 21, 25, 27, 27, 27, 40, 40, 47, 51, 33, 27, 27, 25, 29, 28, 54, 51, 52, 49, 32, 26, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (37, 'meter36', '位置36', 'worker3', '2022-04-23', 24, 25, 24, 29, 28, 29, 41, 42, 45, 52, 33, 25, 26, 29, 27, 28, 51, 50, 54, 49, 31, 26, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (38, 'meter37', '位置37', 'worker3', '2022-04-23', 22, 25, 24, 27, 28, 25, 42, 44, 45, 54, 33, 27, 26, 28, 25, 25, 53, 51, 53, 48, 30, 27, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (39, 'meter38', '位置38', 'worker3', '2022-04-23', 23, 24, 23, 28, 26, 27, 40, 41, 47, 51, 33, 25, 29, 26, 25, 28, 54, 52, 53, 48, 34, 28, 28, 26);
INSERT INTO `electricity_meterinfo` VALUES (40, 'meter39', '位置39', 'worker3', '2022-04-23', 23, 25, 24, 27, 28, 29, 42, 41, 45, 54, 32, 27, 27, 29, 29, 29, 53, 54, 52, 45, 32, 26, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (41, 'meter40', '位置40', 'worker3', '2022-04-23', 21, 24, 23, 27, 25, 29, 42, 41, 46, 54, 30, 27, 29, 25, 26, 25, 51, 53, 50, 46, 30, 27, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (42, 'meter41', '位置41', 'worker3', '2022-04-23', 22, 25, 22, 27, 25, 27, 41, 41, 45, 52, 30, 29, 27, 29, 27, 29, 51, 51, 51, 47, 31, 25, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (43, 'meter42', '位置42', 'worker3', '2022-04-23', 20, 25, 23, 27, 27, 25, 41, 42, 48, 50, 33, 28, 29, 28, 25, 29, 50, 54, 52, 48, 31, 29, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (44, 'meter43', '位置43', 'worker3', '2022-04-23', 22, 25, 23, 25, 25, 28, 43, 41, 45, 51, 34, 29, 29, 25, 28, 27, 50, 54, 52, 45, 30, 29, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (45, 'meter44', '位置44', 'worker3', '2022-04-23', 24, 23, 23, 26, 27, 26, 40, 41, 49, 50, 31, 25, 28, 25, 28, 28, 54, 51, 54, 49, 31, 27, 29, 25);
INSERT INTO `electricity_meterinfo` VALUES (46, 'meter45', '位置45', 'worker4', '2022-04-23', 20, 25, 24, 27, 27, 27, 44, 40, 49, 50, 33, 26, 28, 28, 25, 26, 53, 52, 50, 48, 34, 25, 27, 29);
INSERT INTO `electricity_meterinfo` VALUES (47, 'meter46', '位置46', 'worker4', '2022-04-23', 23, 21, 23, 29, 25, 26, 44, 42, 48, 50, 30, 27, 26, 25, 29, 28, 51, 53, 51, 45, 34, 26, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (48, 'meter47', '位置47', 'worker4', '2022-04-23', 22, 24, 26, 26, 29, 28, 43, 42, 45, 50, 32, 26, 27, 27, 27, 29, 51, 51, 53, 47, 34, 28, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (49, 'meter48', '位置48', 'worker4', '2022-04-23', 21, 21, 26, 26, 28, 25, 42, 43, 45, 50, 30, 29, 27, 29, 25, 28, 50, 54, 50, 45, 34, 27, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (50, 'meter49', '位置49', 'worker4', '2022-04-23', 23, 21, 23, 27, 27, 27, 42, 44, 46, 54, 32, 26, 25, 29, 25, 26, 51, 54, 50, 48, 30, 26, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (51, 'meter50', '位置50', 'worker4', '2022-04-23', 22, 24, 22, 29, 28, 25, 43, 43, 49, 52, 34, 26, 25, 27, 26, 26, 50, 51, 50, 45, 30, 28, 25, 27);
INSERT INTO `electricity_meterinfo` VALUES (52, 'meter51', '位置51', 'worker4', '2022-04-23', 24, 25, 26, 27, 27, 25, 40, 40, 49, 50, 31, 25, 28, 25, 25, 26, 50, 50, 52, 45, 30, 28, 29, 29);
INSERT INTO `electricity_meterinfo` VALUES (53, 'meter52', '位置52', 'worker4', '2022-04-23', 21, 21, 25, 27, 27, 27, 42, 44, 48, 50, 30, 26, 29, 27, 28, 29, 50, 51, 52, 49, 31, 28, 26, 27);
INSERT INTO `electricity_meterinfo` VALUES (54, 'meter53', '位置53', 'worker4', '2022-04-23', 24, 25, 26, 29, 25, 29, 42, 41, 46, 54, 33, 27, 25, 29, 28, 29, 54, 50, 50, 48, 32, 29, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (55, 'meter54', '位置54', 'worker4', '2022-04-23', 23, 23, 24, 28, 27, 25, 44, 43, 47, 51, 31, 25, 29, 29, 27, 29, 54, 51, 51, 48, 32, 26, 28, 29);
INSERT INTO `electricity_meterinfo` VALUES (56, 'meter55', '位置55', 'worker4', '2022-04-23', 23, 22, 23, 25, 27, 27, 42, 43, 49, 52, 32, 27, 25, 27, 27, 28, 52, 52, 50, 45, 34, 28, 27, 26);
INSERT INTO `electricity_meterinfo` VALUES (57, 'meter56', '位置56', 'worker4', '2022-04-23', 23, 22, 26, 25, 27, 27, 44, 40, 49, 54, 30, 25, 26, 26, 29, 27, 54, 54, 52, 48, 34, 29, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (58, 'meter57', '位置57', 'worker4', '2022-04-23', 24, 24, 25, 25, 27, 29, 41, 43, 49, 53, 31, 25, 26, 29, 29, 25, 53, 54, 51, 45, 34, 28, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (59, 'meter58', '位置58', 'worker4', '2022-04-23', 20, 23, 24, 27, 28, 26, 44, 42, 48, 53, 30, 26, 28, 27, 28, 27, 53, 51, 52, 48, 32, 29, 28, 27);
INSERT INTO `electricity_meterinfo` VALUES (60, 'meter59', '位置59', 'worker4', '2022-04-23', 22, 23, 24, 26, 28, 27, 44, 43, 49, 52, 33, 25, 28, 27, 25, 27, 51, 52, 53, 47, 31, 29, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (61, 'meter60', '位置60', 'worker5', '2022-04-23', 20, 24, 22, 27, 28, 27, 44, 42, 47, 50, 31, 28, 25, 28, 28, 26, 51, 50, 52, 45, 33, 29, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (62, 'meter61', '位置61', 'worker5', '2022-04-23', 20, 23, 22, 29, 27, 28, 42, 41, 47, 51, 32, 29, 28, 26, 27, 26, 50, 50, 50, 48, 33, 25, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (63, 'meter62', '位置62', 'worker5', '2022-04-23', 24, 25, 22, 27, 25, 27, 44, 41, 48, 53, 31, 28, 29, 27, 29, 27, 54, 52, 52, 49, 30, 29, 27, 27);
INSERT INTO `electricity_meterinfo` VALUES (64, 'meter63', '位置63', 'worker5', '2022-04-23', 21, 25, 25, 25, 29, 29, 42, 44, 47, 54, 32, 28, 27, 26, 25, 28, 54, 50, 54, 49, 33, 27, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (65, 'meter64', '位置64', 'worker5', '2022-04-23', 22, 21, 25, 25, 25, 25, 41, 41, 47, 53, 32, 29, 25, 27, 26, 27, 51, 51, 50, 48, 34, 28, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (66, 'meter65', '位置65', 'worker5', '2022-04-23', 21, 25, 26, 28, 29, 25, 43, 43, 46, 52, 33, 26, 27, 26, 27, 27, 54, 54, 50, 48, 34, 28, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (67, 'meter66', '位置66', 'worker5', '2022-04-23', 20, 25, 25, 28, 27, 27, 44, 41, 47, 53, 32, 29, 28, 29, 25, 28, 53, 51, 50, 48, 30, 25, 27, 29);
INSERT INTO `electricity_meterinfo` VALUES (68, 'meter67', '位置67', 'worker5', '2022-04-23', 20, 22, 23, 27, 27, 25, 41, 41, 49, 50, 31, 28, 25, 29, 29, 25, 50, 54, 54, 47, 31, 26, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (69, 'meter68', '位置68', 'worker5', '2022-04-23', 24, 23, 26, 29, 28, 29, 44, 40, 48, 53, 33, 28, 26, 29, 25, 27, 52, 52, 50, 46, 30, 27, 28, 27);
INSERT INTO `electricity_meterinfo` VALUES (70, 'meter69', '位置69', 'worker5', '2022-04-23', 22, 21, 23, 28, 26, 26, 40, 42, 48, 52, 32, 28, 27, 29, 26, 26, 51, 51, 52, 47, 34, 28, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (71, 'meter70', '位置70', 'worker5', '2022-04-23', 21, 25, 22, 27, 26, 25, 40, 40, 46, 54, 32, 27, 29, 28, 26, 27, 52, 52, 52, 46, 33, 25, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (72, 'meter71', '位置71', 'worker5', '2022-04-23', 20, 23, 23, 28, 29, 29, 43, 42, 48, 52, 31, 27, 28, 28, 27, 27, 52, 50, 51, 48, 31, 27, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (73, 'meter72', '位置72', 'worker5', '2022-04-23', 23, 21, 25, 28, 29, 28, 44, 40, 45, 50, 32, 28, 25, 27, 25, 25, 54, 54, 54, 49, 32, 25, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (74, 'meter73', '位置73', 'worker5', '2022-04-23', 23, 25, 24, 25, 27, 28, 44, 42, 49, 54, 34, 29, 27, 28, 27, 26, 51, 50, 54, 45, 30, 25, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (75, 'meter74', '位置74', 'worker5', '2022-04-23', 20, 22, 24, 27, 26, 27, 40, 41, 47, 51, 32, 27, 25, 26, 27, 26, 53, 52, 52, 47, 30, 25, 27, 29);
INSERT INTO `electricity_meterinfo` VALUES (76, 'meter75', '位置75', 'worker6', '2022-04-23', 24, 21, 26, 25, 29, 26, 42, 42, 47, 51, 33, 29, 27, 28, 26, 26, 52, 54, 51, 47, 30, 28, 28, 27);
INSERT INTO `electricity_meterinfo` VALUES (77, 'meter76', '位置76', 'worker6', '2022-04-23', 20, 21, 22, 29, 29, 28, 44, 40, 46, 53, 30, 29, 27, 28, 28, 29, 53, 54, 50, 48, 33, 29, 28, 27);
INSERT INTO `electricity_meterinfo` VALUES (78, 'meter77', '位置77', 'worker6', '2022-04-23', 20, 22, 26, 27, 26, 29, 40, 40, 49, 52, 33, 25, 25, 26, 25, 29, 54, 50, 53, 49, 30, 26, 25, 25);
INSERT INTO `electricity_meterinfo` VALUES (79, 'meter78', '位置78', 'worker6', '2022-04-23', 24, 24, 24, 25, 27, 27, 41, 41, 48, 50, 32, 27, 29, 25, 28, 26, 54, 52, 50, 48, 34, 25, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (80, 'meter79', '位置79', 'worker6', '2022-04-23', 23, 23, 26, 28, 29, 26, 44, 41, 45, 54, 32, 28, 25, 25, 28, 26, 51, 52, 50, 48, 34, 27, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (81, 'meter80', '位置80', 'worker6', '2022-04-23', 24, 24, 25, 26, 29, 25, 41, 43, 47, 52, 34, 26, 25, 29, 26, 28, 51, 53, 54, 47, 33, 26, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (82, 'meter81', '位置81', 'worker6', '2022-04-23', 20, 24, 23, 27, 29, 27, 44, 42, 46, 53, 33, 26, 26, 28, 28, 25, 53, 51, 52, 45, 34, 27, 29, 25);
INSERT INTO `electricity_meterinfo` VALUES (83, 'meter82', '位置82', 'worker6', '2022-04-23', 20, 23, 26, 27, 27, 27, 40, 40, 45, 54, 32, 25, 27, 27, 25, 26, 54, 53, 52, 48, 33, 25, 28, 27);
INSERT INTO `electricity_meterinfo` VALUES (84, 'meter83', '位置83', 'worker6', '2022-04-23', 23, 25, 22, 25, 29, 29, 41, 42, 47, 52, 31, 28, 28, 25, 26, 29, 54, 53, 50, 46, 32, 25, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (85, 'meter84', '位置84', 'worker6', '2022-04-23', 20, 25, 25, 27, 25, 26, 41, 42, 48, 54, 32, 29, 27, 25, 27, 25, 51, 53, 51, 45, 31, 27, 28, 27);
INSERT INTO `electricity_meterinfo` VALUES (86, 'meter85', '位置85', 'worker6', '2022-04-23', 21, 22, 25, 29, 25, 27, 41, 41, 49, 51, 32, 27, 28, 27, 25, 25, 51, 53, 54, 46, 33, 26, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (87, 'meter86', '位置86', 'worker6', '2022-04-23', 22, 24, 23, 28, 29, 25, 43, 43, 47, 50, 32, 25, 25, 26, 28, 29, 52, 53, 51, 49, 31, 27, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (88, 'meter87', '位置87', 'worker6', '2022-04-23', 21, 21, 23, 26, 28, 26, 40, 43, 49, 54, 33, 28, 27, 27, 25, 29, 52, 51, 51, 47, 33, 25, 27, 29);
INSERT INTO `electricity_meterinfo` VALUES (89, 'meter88', '位置88', 'worker6', '2022-04-23', 24, 24, 22, 25, 28, 25, 40, 44, 47, 51, 30, 25, 25, 27, 29, 25, 51, 52, 52, 45, 32, 29, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (90, 'meter89', '位置89', 'worker6', '2022-04-23', 22, 21, 26, 28, 28, 26, 40, 43, 47, 52, 33, 26, 29, 27, 28, 26, 50, 51, 53, 45, 33, 27, 25, 27);
INSERT INTO `electricity_meterinfo` VALUES (91, 'meter90', '位置90', 'worker7', '2022-04-23', 22, 25, 25, 25, 29, 25, 40, 41, 46, 50, 34, 27, 28, 29, 25, 26, 50, 53, 51, 48, 30, 26, 29, 25);
INSERT INTO `electricity_meterinfo` VALUES (92, 'meter91', '位置91', 'worker7', '2022-04-23', 22, 24, 24, 25, 26, 27, 40, 40, 46, 50, 34, 26, 26, 26, 25, 25, 54, 51, 51, 49, 32, 25, 27, 29);
INSERT INTO `electricity_meterinfo` VALUES (93, 'meter92', '位置92', 'worker7', '2022-04-23', 23, 22, 24, 28, 28, 28, 44, 42, 48, 53, 33, 25, 29, 25, 29, 26, 53, 50, 54, 46, 34, 26, 29, 27);
INSERT INTO `electricity_meterinfo` VALUES (94, 'meter93', '位置93', 'worker7', '2022-04-23', 20, 23, 25, 28, 28, 28, 43, 41, 46, 51, 32, 25, 27, 27, 29, 29, 54, 53, 50, 47, 32, 28, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (95, 'meter94', '位置94', 'worker7', '2022-04-23', 21, 21, 23, 25, 27, 26, 40, 42, 47, 52, 31, 29, 26, 29, 28, 25, 50, 52, 52, 47, 30, 27, 29, 28);
INSERT INTO `electricity_meterinfo` VALUES (96, 'meter95', '位置95', 'worker7', '2022-04-23', 20, 23, 25, 28, 28, 25, 44, 41, 45, 50, 33, 27, 27, 28, 26, 26, 54, 50, 52, 45, 31, 26, 29, 27);
INSERT INTO `electricity_meterinfo` VALUES (97, 'meter96', '位置96', 'worker7', '2022-04-23', 21, 21, 26, 25, 27, 29, 43, 44, 45, 54, 32, 25, 27, 25, 26, 27, 53, 53, 52, 49, 33, 27, 27, 25);
INSERT INTO `electricity_meterinfo` VALUES (98, 'meter97', '位置97', 'worker7', '2022-04-23', 22, 21, 24, 29, 28, 28, 42, 43, 48, 53, 30, 27, 26, 27, 27, 26, 54, 53, 51, 48, 30, 29, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (99, 'meter98', '位置98', 'worker7', '2022-04-23', 21, 21, 22, 27, 26, 27, 40, 44, 45, 51, 33, 25, 27, 25, 28, 27, 50, 50, 53, 45, 30, 29, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (100, 'meter99', '位置99', 'worker7', '2022-04-23', 24, 25, 22, 27, 27, 29, 43, 43, 48, 54, 32, 26, 27, 26, 27, 25, 50, 51, 52, 47, 32, 26, 26, 27);
INSERT INTO `electricity_meterinfo` VALUES (101, 'meter100', '位置100', 'worker7', '2022-04-23', 24, 22, 24, 29, 26, 27, 40, 41, 46, 52, 34, 27, 27, 27, 27, 29, 51, 53, 54, 45, 32, 26, 29, 29);
INSERT INTO `electricity_meterinfo` VALUES (102, 'meter101', '位置101', 'worker7', '2022-04-23', 20, 23, 26, 26, 27, 28, 42, 41, 47, 54, 34, 28, 28, 27, 27, 28, 53, 52, 54, 47, 31, 28, 25, 27);
INSERT INTO `electricity_meterinfo` VALUES (103, 'meter102', '位置102', 'worker7', '2022-04-23', 22, 23, 24, 27, 26, 27, 43, 44, 48, 53, 34, 28, 25, 28, 28, 29, 50, 51, 51, 49, 32, 28, 26, 27);
INSERT INTO `electricity_meterinfo` VALUES (104, 'meter103', '位置103', 'worker7', '2022-04-23', 22, 22, 22, 26, 29, 29, 41, 44, 48, 51, 30, 27, 28, 28, 27, 26, 51, 54, 50, 48, 34, 27, 27, 25);
INSERT INTO `electricity_meterinfo` VALUES (105, 'meter104', '位置104', 'worker7', '2022-04-23', 22, 21, 24, 29, 25, 27, 44, 43, 46, 51, 32, 29, 25, 28, 26, 29, 52, 52, 54, 48, 31, 25, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (106, 'meter105', '位置105', 'worker8', '2022-04-23', 24, 24, 22, 28, 26, 27, 40, 40, 47, 52, 31, 28, 27, 27, 28, 29, 53, 50, 51, 49, 32, 29, 25, 27);
INSERT INTO `electricity_meterinfo` VALUES (107, 'meter106', '位置106', 'worker8', '2022-04-23', 23, 24, 23, 28, 28, 25, 42, 41, 49, 51, 33, 29, 27, 29, 25, 25, 51, 51, 52, 48, 31, 28, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (108, 'meter107', '位置107', 'worker8', '2022-04-23', 21, 25, 23, 29, 29, 28, 44, 41, 46, 52, 30, 29, 27, 29, 29, 25, 54, 52, 50, 47, 33, 25, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (109, 'meter108', '位置108', 'worker8', '2022-04-23', 20, 21, 25, 28, 25, 28, 42, 44, 49, 52, 34, 29, 29, 28, 26, 25, 54, 54, 51, 47, 34, 29, 28, 29);
INSERT INTO `electricity_meterinfo` VALUES (110, 'meter109', '位置109', 'worker8', '2022-04-23', 21, 22, 24, 26, 28, 25, 43, 44, 48, 53, 31, 26, 28, 27, 25, 28, 53, 54, 53, 49, 30, 27, 28, 29);
INSERT INTO `electricity_meterinfo` VALUES (111, 'meter110', '位置110', 'worker8', '2022-04-23', 20, 21, 25, 25, 26, 29, 41, 41, 47, 51, 33, 25, 25, 25, 26, 25, 50, 54, 54, 48, 34, 27, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (112, 'meter111', '位置111', 'worker8', '2022-04-23', 20, 23, 24, 29, 27, 29, 44, 44, 46, 53, 34, 26, 28, 29, 25, 26, 50, 54, 54, 49, 34, 29, 25, 27);
INSERT INTO `electricity_meterinfo` VALUES (113, 'meter112', '位置112', 'worker8', '2022-04-23', 22, 25, 24, 25, 27, 29, 42, 43, 48, 52, 33, 29, 25, 28, 26, 26, 53, 53, 52, 49, 34, 28, 29, 28);
INSERT INTO `electricity_meterinfo` VALUES (114, 'meter113', '位置113', 'worker8', '2022-04-23', 22, 25, 24, 28, 29, 26, 44, 41, 47, 52, 31, 28, 27, 28, 29, 28, 54, 50, 52, 46, 32, 28, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (115, 'meter114', '位置114', 'worker8', '2022-04-23', 22, 22, 25, 26, 28, 26, 40, 43, 47, 54, 30, 27, 25, 29, 29, 25, 54, 53, 50, 48, 33, 26, 26, 28);
INSERT INTO `electricity_meterinfo` VALUES (116, 'meter115', '位置115', 'worker8', '2022-04-23', 21, 25, 25, 28, 29, 27, 44, 41, 47, 54, 32, 29, 26, 26, 28, 29, 53, 54, 50, 45, 31, 27, 27, 25);
INSERT INTO `electricity_meterinfo` VALUES (117, 'meter116', '位置116', 'worker8', '2022-04-23', 24, 24, 24, 28, 27, 28, 42, 43, 48, 53, 34, 25, 26, 28, 27, 25, 54, 50, 52, 45, 33, 28, 26, 27);
INSERT INTO `electricity_meterinfo` VALUES (118, 'meter117', '位置117', 'worker8', '2022-04-23', 24, 21, 24, 25, 25, 25, 41, 42, 46, 50, 30, 26, 29, 25, 28, 27, 50, 51, 52, 45, 34, 25, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (119, 'meter118', '位置118', 'worker8', '2022-04-23', 23, 23, 22, 25, 27, 27, 43, 42, 49, 51, 30, 29, 26, 28, 28, 29, 52, 52, 54, 46, 32, 26, 27, 26);
INSERT INTO `electricity_meterinfo` VALUES (120, 'meter119', '位置119', 'worker8', '2022-04-23', 23, 25, 23, 29, 27, 25, 41, 41, 47, 54, 34, 27, 29, 26, 25, 29, 50, 50, 51, 45, 33, 29, 29, 27);
INSERT INTO `electricity_meterinfo` VALUES (121, 'meter120', '位置120', 'worker9', '2022-04-23', 21, 24, 22, 25, 28, 27, 41, 44, 48, 54, 30, 26, 28, 29, 26, 25, 54, 51, 51, 47, 32, 27, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (122, 'meter121', '位置121', 'worker9', '2022-04-23', 21, 24, 23, 27, 25, 28, 44, 41, 46, 52, 31, 29, 27, 27, 29, 26, 54, 54, 52, 47, 32, 27, 26, 29);
INSERT INTO `electricity_meterinfo` VALUES (123, 'meter122', '位置122', 'worker9', '2022-04-23', 22, 23, 23, 25, 25, 25, 42, 42, 46, 50, 32, 27, 25, 29, 27, 26, 51, 51, 52, 46, 32, 29, 26, 29);
INSERT INTO `electricity_meterinfo` VALUES (124, 'meter123', '位置123', 'worker9', '2022-04-23', 22, 22, 23, 26, 29, 26, 44, 42, 49, 50, 30, 27, 26, 27, 26, 26, 53, 53, 52, 48, 32, 28, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (125, 'meter124', '位置124', 'worker9', '2022-04-23', 22, 23, 25, 26, 25, 26, 41, 42, 48, 52, 30, 26, 29, 26, 26, 27, 54, 53, 51, 45, 33, 26, 29, 25);
INSERT INTO `electricity_meterinfo` VALUES (126, 'meter125', '位置125', 'worker9', '2022-04-23', 20, 22, 23, 25, 29, 29, 41, 44, 46, 51, 31, 26, 28, 27, 25, 28, 54, 50, 50, 47, 30, 27, 26, 27);
INSERT INTO `electricity_meterinfo` VALUES (127, 'meter126', '位置126', 'worker9', '2022-04-23', 21, 21, 24, 28, 27, 26, 40, 43, 47, 50, 32, 25, 26, 25, 29, 25, 51, 52, 52, 49, 32, 27, 28, 29);
INSERT INTO `electricity_meterinfo` VALUES (128, 'meter127', '位置127', 'worker9', '2022-04-23', 21, 25, 22, 26, 28, 29, 44, 40, 48, 50, 34, 28, 29, 28, 28, 28, 54, 51, 54, 49, 30, 27, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (129, 'meter128', '位置128', 'worker9', '2022-04-23', 21, 21, 23, 27, 25, 29, 40, 44, 46, 54, 30, 25, 27, 28, 29, 27, 52, 54, 53, 48, 33, 28, 26, 29);
INSERT INTO `electricity_meterinfo` VALUES (130, 'meter129', '位置129', 'worker9', '2022-04-23', 22, 21, 25, 29, 29, 27, 42, 42, 45, 50, 34, 25, 25, 28, 27, 27, 54, 52, 52, 49, 30, 25, 28, 26);
INSERT INTO `electricity_meterinfo` VALUES (131, 'meter130', '位置130', 'worker9', '2022-04-23', 23, 24, 24, 27, 29, 26, 42, 41, 46, 52, 32, 26, 25, 26, 25, 29, 54, 52, 50, 48, 34, 25, 25, 27);
INSERT INTO `electricity_meterinfo` VALUES (132, 'meter131', '位置131', 'worker9', '2022-04-23', 24, 22, 23, 29, 29, 28, 43, 42, 47, 50, 31, 25, 29, 28, 25, 27, 52, 51, 54, 48, 33, 25, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (133, 'meter132', '位置132', 'worker9', '2022-04-23', 20, 21, 25, 26, 29, 28, 40, 43, 45, 54, 33, 28, 28, 27, 27, 29, 54, 52, 50, 49, 33, 29, 27, 27);
INSERT INTO `electricity_meterinfo` VALUES (134, 'meter133', '位置133', 'worker9', '2022-04-23', 23, 23, 24, 28, 26, 25, 41, 41, 47, 50, 31, 28, 27, 29, 29, 27, 50, 50, 53, 45, 32, 26, 27, 26);
INSERT INTO `electricity_meterinfo` VALUES (135, 'meter134', '位置134', 'worker9', '2022-04-23', 21, 24, 22, 28, 25, 29, 42, 40, 49, 52, 33, 27, 29, 29, 26, 25, 53, 53, 52, 47, 30, 25, 28, 26);
INSERT INTO `electricity_meterinfo` VALUES (136, 'meter135', '位置135', 'worker10', '2022-04-23', 23, 21, 25, 27, 25, 26, 41, 44, 49, 51, 33, 28, 28, 29, 28, 25, 53, 53, 50, 48, 32, 25, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (137, 'meter136', '位置136', 'worker10', '2022-04-23', 24, 21, 25, 26, 27, 25, 43, 42, 45, 52, 30, 28, 26, 28, 29, 27, 53, 50, 53, 48, 33, 25, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (138, 'meter137', '位置137', 'worker10', '2022-04-23', 23, 25, 23, 25, 26, 27, 40, 44, 45, 52, 30, 26, 27, 28, 29, 28, 54, 50, 53, 46, 30, 27, 28, 27);
INSERT INTO `electricity_meterinfo` VALUES (139, 'meter138', '位置138', 'worker10', '2022-04-23', 20, 21, 22, 25, 29, 25, 42, 43, 48, 50, 31, 29, 28, 28, 25, 27, 51, 51, 51, 48, 31, 27, 28, 29);
INSERT INTO `electricity_meterinfo` VALUES (140, 'meter139', '位置139', 'worker10', '2022-04-23', 24, 23, 23, 28, 29, 28, 40, 44, 48, 53, 30, 28, 25, 26, 29, 25, 54, 53, 54, 47, 32, 27, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (141, 'meter140', '位置140', 'worker10', '2022-04-23', 22, 23, 24, 26, 27, 28, 40, 44, 46, 54, 31, 29, 29, 26, 28, 25, 54, 53, 52, 46, 32, 25, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (142, 'meter141', '位置141', 'worker10', '2022-04-23', 24, 25, 25, 29, 25, 25, 41, 41, 45, 53, 31, 28, 27, 29, 26, 29, 50, 54, 53, 47, 30, 26, 26, 28);
INSERT INTO `electricity_meterinfo` VALUES (143, 'meter142', '位置142', 'worker10', '2022-04-23', 20, 22, 25, 29, 26, 26, 42, 44, 45, 50, 32, 28, 25, 26, 28, 25, 53, 53, 51, 47, 31, 27, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (144, 'meter143', '位置143', 'worker10', '2022-04-23', 24, 22, 22, 25, 28, 25, 42, 43, 46, 50, 30, 25, 26, 27, 25, 28, 53, 51, 54, 47, 30, 27, 27, 25);
INSERT INTO `electricity_meterinfo` VALUES (145, 'meter144', '位置144', 'worker10', '2022-04-23', 21, 25, 26, 25, 26, 28, 44, 42, 49, 52, 31, 27, 28, 28, 25, 29, 50, 54, 54, 48, 31, 26, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (146, 'meter145', '位置145', 'worker10', '2022-04-23', 23, 25, 25, 26, 26, 26, 42, 41, 45, 52, 33, 29, 25, 29, 29, 25, 52, 50, 53, 48, 30, 25, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (147, 'meter146', '位置146', 'worker10', '2022-04-23', 21, 21, 22, 28, 28, 25, 44, 43, 47, 53, 31, 29, 25, 26, 27, 25, 52, 53, 54, 47, 30, 29, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (148, 'meter147', '位置147', 'worker10', '2022-04-23', 20, 24, 26, 27, 26, 29, 42, 44, 49, 51, 32, 28, 29, 26, 29, 29, 50, 53, 53, 48, 32, 27, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (149, 'meter148', '位置148', 'worker10', '2022-04-23', 20, 24, 25, 27, 27, 29, 42, 43, 46, 54, 33, 25, 27, 25, 28, 29, 50, 54, 51, 47, 33, 25, 26, 29);
INSERT INTO `electricity_meterinfo` VALUES (150, 'meter149', '位置149', 'worker10', '2022-04-23', 24, 25, 26, 26, 29, 25, 40, 40, 47, 51, 34, 25, 29, 29, 27, 29, 52, 53, 54, 48, 34, 25, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (151, 'meter150', '位置150', 'worker11', '2022-04-23', 20, 25, 23, 26, 29, 29, 43, 44, 46, 54, 32, 29, 28, 27, 29, 28, 51, 52, 54, 49, 33, 28, 29, 25);
INSERT INTO `electricity_meterinfo` VALUES (152, 'meter151', '位置151', 'worker11', '2022-04-23', 23, 24, 26, 25, 25, 29, 41, 42, 47, 50, 32, 25, 28, 28, 27, 25, 51, 53, 51, 49, 34, 29, 25, 27);
INSERT INTO `electricity_meterinfo` VALUES (153, 'meter152', '位置152', 'worker11', '2022-04-23', 20, 24, 23, 29, 27, 26, 41, 40, 45, 53, 31, 26, 29, 25, 28, 29, 50, 51, 51, 49, 30, 28, 27, 27);
INSERT INTO `electricity_meterinfo` VALUES (154, 'meter153', '位置153', 'worker11', '2022-04-23', 22, 21, 24, 28, 28, 28, 40, 43, 49, 52, 34, 28, 29, 28, 26, 29, 52, 51, 50, 48, 30, 26, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (155, 'meter154', '位置154', 'worker11', '2022-04-23', 22, 22, 24, 26, 27, 25, 43, 41, 48, 54, 34, 25, 29, 26, 27, 27, 50, 52, 54, 48, 30, 25, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (156, 'meter155', '位置155', 'worker11', '2022-04-23', 22, 21, 23, 25, 28, 25, 41, 40, 47, 52, 30, 27, 27, 27, 26, 27, 52, 52, 52, 45, 31, 28, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (157, 'meter156', '位置156', 'worker11', '2022-04-23', 23, 23, 25, 29, 28, 28, 41, 44, 45, 54, 32, 25, 27, 26, 25, 26, 52, 53, 50, 46, 33, 28, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (158, 'meter157', '位置157', 'worker11', '2022-04-23', 21, 25, 23, 26, 27, 25, 42, 43, 48, 51, 31, 28, 27, 25, 28, 26, 54, 53, 50, 46, 31, 25, 29, 29);
INSERT INTO `electricity_meterinfo` VALUES (159, 'meter158', '位置158', 'worker11', '2022-04-23', 21, 22, 26, 28, 26, 27, 44, 42, 45, 50, 30, 25, 28, 28, 27, 27, 53, 51, 51, 49, 34, 26, 25, 28);
INSERT INTO `electricity_meterinfo` VALUES (160, 'meter159', '位置159', 'worker11', '2022-04-23', 21, 21, 24, 26, 28, 25, 44, 44, 46, 51, 30, 25, 25, 29, 25, 25, 53, 53, 51, 45, 31, 27, 26, 28);
INSERT INTO `electricity_meterinfo` VALUES (161, 'meter160', '位置160', 'worker11', '2022-04-23', 22, 21, 26, 29, 29, 28, 41, 44, 45, 51, 34, 27, 29, 29, 27, 28, 51, 52, 53, 48, 31, 26, 26, 29);
INSERT INTO `electricity_meterinfo` VALUES (162, 'meter161', '位置161', 'worker11', '2022-04-23', 21, 23, 26, 26, 26, 28, 44, 40, 47, 50, 33, 26, 29, 25, 25, 29, 52, 50, 52, 49, 34, 28, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (163, 'meter162', '位置162', 'worker11', '2022-04-23', 22, 22, 26, 28, 29, 25, 42, 40, 47, 52, 31, 29, 26, 27, 28, 29, 50, 50, 52, 45, 32, 27, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (164, 'meter163', '位置163', 'worker11', '2022-04-23', 20, 23, 25, 25, 27, 26, 42, 43, 47, 50, 34, 29, 26, 27, 29, 29, 53, 52, 51, 49, 31, 27, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (165, 'meter164', '位置164', 'worker11', '2022-04-23', 23, 24, 25, 27, 26, 28, 41, 42, 47, 51, 30, 28, 25, 28, 26, 28, 54, 51, 54, 49, 31, 26, 28, 27);
INSERT INTO `electricity_meterinfo` VALUES (166, 'meter165', '位置165', 'worker12', '2022-04-23', 23, 25, 22, 27, 26, 27, 40, 44, 47, 54, 31, 28, 28, 25, 29, 28, 54, 51, 51, 45, 31, 28, 29, 29);
INSERT INTO `electricity_meterinfo` VALUES (167, 'meter166', '位置166', 'worker12', '2022-04-23', 20, 23, 26, 25, 26, 28, 43, 40, 45, 51, 33, 26, 27, 28, 27, 26, 53, 50, 52, 45, 31, 26, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (168, 'meter167', '位置167', 'worker12', '2022-04-23', 23, 25, 26, 26, 27, 25, 43, 43, 49, 50, 33, 27, 26, 25, 28, 26, 51, 54, 53, 47, 33, 29, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (169, 'meter168', '位置168', 'worker12', '2022-04-23', 20, 25, 23, 26, 27, 29, 40, 43, 46, 50, 31, 27, 28, 27, 26, 29, 52, 54, 53, 45, 33, 29, 25, 25);
INSERT INTO `electricity_meterinfo` VALUES (170, 'meter169', '位置169', 'worker12', '2022-04-23', 21, 21, 24, 28, 27, 26, 43, 41, 48, 54, 33, 25, 29, 25, 28, 29, 53, 51, 52, 49, 31, 29, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (171, 'meter170', '位置170', 'worker12', '2022-04-23', 23, 23, 24, 26, 26, 28, 42, 44, 49, 50, 34, 29, 28, 28, 25, 27, 54, 54, 51, 47, 32, 26, 29, 28);
INSERT INTO `electricity_meterinfo` VALUES (172, 'meter171', '位置171', 'worker12', '2022-04-23', 23, 23, 23, 28, 29, 25, 43, 43, 45, 54, 34, 28, 26, 25, 26, 25, 50, 50, 52, 48, 33, 25, 26, 27);
INSERT INTO `electricity_meterinfo` VALUES (173, 'meter172', '位置172', 'worker12', '2022-04-23', 20, 22, 23, 29, 28, 28, 42, 42, 46, 51, 34, 27, 28, 29, 29, 25, 53, 54, 54, 46, 30, 26, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (174, 'meter173', '位置173', 'worker12', '2022-04-23', 23, 25, 25, 26, 27, 25, 44, 43, 45, 50, 32, 27, 27, 29, 27, 28, 53, 54, 52, 46, 31, 25, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (175, 'meter174', '位置174', 'worker12', '2022-04-23', 21, 21, 26, 25, 25, 28, 40, 42, 49, 52, 33, 25, 27, 28, 27, 26, 52, 52, 50, 49, 30, 26, 29, 27);
INSERT INTO `electricity_meterinfo` VALUES (176, 'meter175', '位置175', 'worker12', '2022-04-23', 21, 21, 22, 27, 27, 27, 40, 44, 46, 54, 34, 27, 28, 25, 29, 25, 52, 51, 51, 47, 30, 29, 29, 28);
INSERT INTO `electricity_meterinfo` VALUES (177, 'meter176', '位置176', 'worker12', '2022-04-23', 24, 24, 25, 25, 28, 26, 41, 43, 49, 50, 34, 26, 28, 25, 29, 25, 50, 54, 50, 46, 31, 28, 29, 25);
INSERT INTO `electricity_meterinfo` VALUES (178, 'meter177', '位置177', 'worker12', '2022-04-23', 22, 22, 23, 25, 28, 25, 44, 43, 48, 54, 34, 25, 27, 27, 29, 26, 50, 53, 54, 46, 31, 29, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (179, 'meter178', '位置178', 'worker12', '2022-04-23', 24, 25, 26, 26, 28, 28, 44, 44, 47, 53, 31, 28, 27, 29, 25, 26, 53, 52, 52, 48, 30, 26, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (180, 'meter179', '位置179', 'worker12', '2022-04-23', 20, 24, 22, 29, 29, 27, 42, 44, 47, 51, 31, 27, 26, 29, 26, 29, 50, 53, 51, 49, 32, 27, 29, 29);
INSERT INTO `electricity_meterinfo` VALUES (181, 'meter180', '位置180', 'worker13', '2022-04-23', 21, 22, 26, 28, 25, 26, 40, 44, 45, 52, 34, 29, 27, 29, 29, 27, 53, 50, 51, 49, 32, 29, 26, 28);
INSERT INTO `electricity_meterinfo` VALUES (182, 'meter181', '位置181', 'worker13', '2022-04-23', 20, 21, 22, 25, 27, 28, 44, 41, 46, 54, 33, 27, 29, 27, 26, 25, 52, 52, 51, 49, 30, 25, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (183, 'meter182', '位置182', 'worker13', '2022-04-23', 24, 24, 24, 27, 25, 28, 40, 44, 48, 50, 30, 26, 27, 28, 27, 29, 52, 52, 53, 45, 30, 27, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (184, 'meter183', '位置183', 'worker13', '2022-04-23', 20, 25, 22, 29, 26, 29, 42, 43, 47, 54, 32, 29, 26, 28, 25, 28, 52, 50, 52, 46, 30, 27, 29, 28);
INSERT INTO `electricity_meterinfo` VALUES (185, 'meter184', '位置184', 'worker13', '2022-04-23', 21, 25, 22, 25, 29, 27, 44, 40, 45, 52, 32, 28, 25, 28, 29, 29, 53, 50, 54, 45, 34, 26, 29, 27);
INSERT INTO `electricity_meterinfo` VALUES (186, 'meter185', '位置185', 'worker13', '2022-04-23', 20, 23, 26, 29, 27, 29, 42, 40, 48, 52, 32, 26, 26, 29, 29, 26, 54, 51, 53, 45, 33, 25, 26, 26);
INSERT INTO `electricity_meterinfo` VALUES (187, 'meter186', '位置186', 'worker13', '2022-04-23', 20, 23, 22, 26, 28, 27, 42, 42, 45, 54, 31, 27, 27, 28, 26, 26, 54, 54, 52, 46, 33, 26, 28, 28);
INSERT INTO `electricity_meterinfo` VALUES (188, 'meter187', '位置187', 'worker13', '2022-04-23', 23, 22, 23, 28, 29, 25, 43, 41, 49, 54, 34, 27, 29, 29, 27, 27, 53, 51, 54, 46, 33, 28, 25, 26);
INSERT INTO `electricity_meterinfo` VALUES (189, 'meter188', '位置188', 'worker13', '2022-04-23', 24, 24, 24, 25, 26, 29, 41, 42, 49, 50, 34, 26, 26, 26, 29, 26, 53, 51, 52, 46, 34, 28, 25, 29);
INSERT INTO `electricity_meterinfo` VALUES (190, 'meter189', '位置189', 'worker13', '2022-04-23', 21, 23, 23, 26, 25, 26, 44, 43, 48, 52, 32, 25, 26, 28, 26, 27, 53, 50, 52, 48, 32, 28, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (191, 'meter190', '位置190', 'worker13', '2022-04-23', 23, 22, 25, 29, 28, 28, 42, 44, 46, 51, 31, 27, 27, 29, 26, 26, 53, 51, 53, 47, 33, 26, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (192, 'meter191', '位置191', 'worker13', '2022-04-23', 20, 25, 22, 29, 27, 29, 44, 41, 46, 50, 30, 27, 29, 27, 29, 25, 52, 53, 52, 46, 31, 27, 27, 28);
INSERT INTO `electricity_meterinfo` VALUES (193, 'meter192', '位置192', 'worker13', '2022-04-23', 20, 25, 23, 26, 26, 25, 44, 41, 48, 53, 32, 25, 25, 27, 29, 29, 51, 50, 53, 47, 32, 28, 28, 26);
INSERT INTO `electricity_meterinfo` VALUES (194, 'meter193', '位置193', 'worker13', '2022-04-23', 22, 23, 26, 27, 26, 29, 43, 40, 45, 53, 34, 29, 28, 28, 27, 29, 53, 52, 51, 45, 32, 28, 28, 25);
INSERT INTO `electricity_meterinfo` VALUES (195, 'meter194', '位置194', 'worker13', '2022-04-23', 21, 22, 22, 28, 28, 27, 42, 43, 47, 54, 34, 25, 29, 26, 25, 25, 52, 52, 52, 46, 33, 26, 26, 29);
INSERT INTO `electricity_meterinfo` VALUES (196, 'meter195', '位置195', 'worker14', '2022-04-23', 24, 21, 23, 29, 28, 29, 40, 40, 49, 50, 32, 25, 25, 26, 26, 28, 50, 50, 50, 48, 33, 27, 27, 25);
INSERT INTO `electricity_meterinfo` VALUES (197, 'meter196', '位置196', 'worker14', '2022-04-23', 24, 23, 23, 27, 25, 26, 43, 40, 49, 52, 32, 29, 25, 27, 29, 26, 53, 54, 50, 48, 33, 25, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (198, 'meter197', '位置197', 'worker14', '2022-04-23', 21, 25, 26, 29, 28, 25, 42, 42, 45, 54, 33, 25, 29, 28, 29, 27, 54, 54, 52, 45, 32, 26, 29, 26);
INSERT INTO `electricity_meterinfo` VALUES (199, 'meter198', '位置198', 'worker14', '2022-04-23', 20, 24, 22, 26, 25, 27, 43, 40, 47, 51, 31, 26, 26, 26, 27, 28, 50, 53, 52, 47, 34, 28, 26, 25);
INSERT INTO `electricity_meterinfo` VALUES (200, 'meter199', '位置199', 'worker14', '2022-04-23', 21, 21, 24, 25, 28, 27, 40, 40, 49, 51, 34, 28, 27, 26, 28, 26, 50, 52, 53, 49, 31, 25, 26, 28);

-- ----------------------------
-- Table structure for employ_simply
-- ----------------------------
DROP TABLE IF EXISTS `employ_simply`;
CREATE TABLE `employ_simply`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `gender` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `age` int(11) NULL DEFAULT NULL,
  `id_card` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `join_time` datetime NULL DEFAULT NULL,
  `salary` float NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of employ_simply
-- ----------------------------
INSERT INTO `employ_simply` VALUES (3, '张三', '男', 22, '210203197503102721', '2022-02-09 00:00:00', 4100);
INSERT INTO `employ_simply` VALUES (4, '李斯', '男', 21, '431202198811101720', '2022-03-01 00:00:00', 5000);
INSERT INTO `employ_simply` VALUES (5, '小花', '女', 32, '130821199103278829', '2021-12-16 00:00:00', 4500);
INSERT INTO `employ_simply` VALUES (6, '小春', '女', 26, '520323197806058856', '2022-01-05 00:00:00', 6000);
INSERT INTO `employ_simply` VALUES (7, '李华', '男', 28, '350105199506138487', '2021-12-30 00:00:00', 5200);
INSERT INTO `employ_simply` VALUES (8, '小强', '男', 29, '610729197408202551', '2022-02-03 00:00:00', 4900);
INSERT INTO `employ_simply` VALUES (9, '大鹏', '男', 31, '820000195008115837', '2022-02-01 00:00:00', 5300);
INSERT INTO `employ_simply` VALUES (10, '芳芳', '女', 24, '450101197405207446', '2022-02-28 00:00:00', 4800);
INSERT INTO `employ_simply` VALUES (11, '小美', '女', 29, '411626198204167401', '2021-10-01 00:00:00', 5900);
INSERT INTO `employ_simply` VALUES (12, '小飞', '男', 33, '654022197901228286', '2021-11-01 00:00:00', 4600);
INSERT INTO `employ_simply` VALUES (13, '小冰', '女', 35, '152224198908049211', '2021-11-12 00:00:00', 4800);
INSERT INTO `employ_simply` VALUES (14, '舒宏', '男', 27, '450231197477207446', '2022-04-01 00:00:00', 5000);
INSERT INTO `employ_simply` VALUES (15, '刘德华', '男', 18, '515165189132065', '2022-03-19 00:00:00', 8230);
INSERT INTO `employ_simply` VALUES (19, '亚丝娜', '女', 18, '50011620010817655', '2022-03-19 21:07:32', 1234);

-- ----------------------------
-- Table structure for img_path
-- ----------------------------
DROP TABLE IF EXISTS `img_path`;
CREATE TABLE `img_path`  (
  `id` int(11) NOT NULL,
  `time` datetime NULL DEFAULT NULL,
  `path` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of img_path
-- ----------------------------
INSERT INTO `img_path` VALUES (1, '2022-04-28 08:55:20', 'image/1.png');

-- ----------------------------
-- Table structure for warnings
-- ----------------------------
DROP TABLE IF EXISTS `warnings`;
CREATE TABLE `warnings`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `date` date NULL DEFAULT NULL,
  `meter_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `position` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `reason` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `employee_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of warnings
-- ----------------------------
INSERT INTO `warnings` VALUES (1, '2022-04-23', 'meter39', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker3');
INSERT INTO `warnings` VALUES (2, '2022-04-23', 'meter67', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker5');
INSERT INTO `warnings` VALUES (3, '2022-04-23', 'meter71', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker5');
INSERT INTO `warnings` VALUES (4, '2022-04-23', 'meter100', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker7');
INSERT INTO `warnings` VALUES (5, '2022-04-23', 'meter68', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker5');
INSERT INTO `warnings` VALUES (6, '2022-04-23', 'meter38', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker3');
INSERT INTO `warnings` VALUES (7, '2022-04-23', 'meter20', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker2');
INSERT INTO `warnings` VALUES (8, '2022-04-23', 'meter66', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker5');
INSERT INTO `warnings` VALUES (9, '2022-04-23', 'meter45', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker4');
INSERT INTO `warnings` VALUES (10, '2022-04-23', 'meter74', '重庆市九龙坡区xx市xx小区xx号', '电压过低', 'worker5');

SET FOREIGN_KEY_CHECKS = 1;
