import random

import cv2
import numpy as np


def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def get_template(size):
    number_images = []
    for i in range(0, 10):
        img = cv2.imread("../number_images/"+str(i)+".png")
        ref = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # 二值图像
        binary = cv2.threshold(ref, 127, 255, cv2.THRESH_BINARY)[1]
        # show('ref', ref)
        tImg = cv2.resize(binary, size)
        number_images.append(tImg)
    return number_images


template_images = get_template((50, 80))
for i in range(0, len(template_images)):
    targetImg = template_images[i]
    show(str(i), targetImg)
