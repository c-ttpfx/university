import cv2
import numpy as np


def my_imread(src):
    return cv2.resize(cv2.imread(src), (443, 591))


def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    # cv2.destroyAllWindows()


def get_num_img(img):
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    kernel = np.ones((2, 2), np.uint8)
    img_blur2 = cv2.GaussianBlur(gray_img, (5, 5), 5)
    result, binary_img = cv2.threshold(img_blur2, 127, 255, cv2.THRESH_BINARY)

    contours, hierarchy = cv2.findContours(binary_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    img1 = cv2.drawContours(img.copy(), contours, -1, (0, 0, 255), 1)
    img = img.copy()
    new_img1 = img
    x2, y2, w2, h2 = 0, 0, 0, 0
    for i in range(0, len(contours)):
        x1, y1, w1, h1 = cv2.boundingRect(contours[i])
        if w1 > h1 * 4 and w1 > 200 and h1 > 50:
            new_img1 = img[y1:y1 + h1, x1:x1 + w1]
            x2, y2, w2, h2 = x1, y1, w1, h1
    return (x2, y2, w2, h2), new_img1


def get_contours(img):
    new_img = img.copy()
    gray_img = cv2.cvtColor(new_img, cv2.COLOR_BGR2GRAY)
    result, binary_img = cv2.threshold(gray_img, 127, 255, cv2.THRESH_BINARY)
    kernel = np.ones((5, 5), np.uint8)
    erosion = cv2.erode(binary_img, kernel, iterations=1)
    # show("binary", erosion)
    contours, hierarchy = cv2.findContours(erosion, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    img1 = cv2.drawContours(img, contours, -1, (0, 0, 255), 2)
    # show("img1", img1)
    group = []
    for i in range(0, len(contours)):
        x, y, w, h = cv2.boundingRect(contours[i])
        if 10 < w < h and h > 30 and x > 50:
            group.append([x, y, w, h])
            new_img = cv2.rectangle(new_img, (x, y), (x + w, y + h), (0, 0, 255), 2)
    # show("img", new_img)
    return group


def get_contours_data(my_img):
    img_left = my_img[0:my_img.shape[0], 0:my_img.shape[1] - 45]
    img_left = cv2.copyMakeBorder(img_left, 0, 0, 0, my_img.shape[1] - img_left.shape[1],
                                  borderType=cv2.BORDER_CONSTANT, value=(255, 255, 255))
    img_right = my_img[0:my_img.shape[0], my_img.shape[1] - 40:my_img.shape[1]]
    img_right = cv2.copyMakeBorder(img_right, 0, 0, my_img.shape[1] - img_right.shape[1], 0,
                                   borderType=cv2.BORDER_CONSTANT, value=(255, 255, 255))
    left_contours = get_contours(img_left)
    right_contours = get_contours(img_right)
    all_contours = left_contours + right_contours
    return all_contours


vc = cv2.VideoCapture('../number_images/table1.MP4')

if vc.isOpened():
    open_, frame = vc.read()
else:
    open_ = False
pre_x, pre_y, pre_w, pre_h = 0, 0, 0, 0
num = 0
while open_:
    ret, frame = vc.read()
    num += 1
    if frame is None:
        break
    if num % 2 == 0:

        if ret:
            img = cv2.resize(frame, (443, 591))
            position, new_img2 = get_num_img(img)
            print(position)
            my_img1 = cv2.resize(new_img2, (224, 60))
            all_contours = get_contours_data(my_img1)
            all_contours = sorted(all_contours, key=lambda lis: lis[0])
            for contour in all_contours:
                x, y, w, h = contour
                my_img = cv2.rectangle(my_img1, (x, y), (x + w, y + h), (0, 0, 255), 2)

            x, y, w, h = position
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            try:
                # 计算缩放因子
                kx = new_img2.shape[1] / 224
                ky = new_img2.shape[0] / 60
                # 计算数字区域
                w = (all_contours[len(all_contours) - 1][0] - all_contours[0][0] + all_contours[len(all_contours) - 1][
                    2]) * kx
                h = (all_contours[len(all_contours) - 1][3]) * ky
                x = (all_contours[0][0]) * kx + position[0]
                y = (all_contours[0][1]) * ky + position[1]
                pre_x, pre_y, pre_w, pre_h = x, y, w, h
            except:
                x, y, w, h = pre_x, pre_y, pre_w, pre_h

            cv2.rectangle(img, (round(x), round(y)), (round(x + w), round(y + h)), (102, 174, 55), 2)

            cv2.imshow('video', img)
            if cv2.waitKey(1) & 0xFF == 27:
                break

vc.release()
cv2.destroyAllWindows()
