import cv2
import numpy as np


def my_imread(src):
    return cv2.resize(cv2.imread(src), (443, 591))


def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    # cv2.destroyAllWindows()


def get_num_img(img):
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    kernel = np.ones((2, 2), np.uint8)
    img_blur2 = cv2.GaussianBlur(gray_img, (5, 5), 5)
    result, binary_img = cv2.threshold(img_blur2, 127, 255, cv2.THRESH_BINARY)
    # show("binary_img",binary_img)
    contours, hierarchy = cv2.findContours(binary_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    img1 = cv2.drawContours(img.copy(), contours, -1, (0, 0, 255), 1)
    # show("img1",img1)
    img = img.copy()
    new_img1 = img
    x2, y2, w2, h2 = 0, 0, 0, 0
    for i in range(0, len(contours)):
        x1, y1, w1, h1 = cv2.boundingRect(contours[i])
        if w1 > h1 * 4 and w1 > 200 and h1 > 50:
            new_img1 = img[y1:y1 + h1, x1:x1 + w1]
            x2, y2, w2, h2 = x1, y1, w1, h1
    xxx = cv2.rectangle(img, (x2, y2), (x2 + w2, y2 + h2), (0, 0, 255), 2)
    # show("xxx",xxx)
    return (x2, y2, w2, h2), new_img1


def get_contours(img):
    new_img = img.copy()
    gray_img = cv2.cvtColor(new_img, cv2.COLOR_BGR2GRAY)
    result, binary_img = cv2.threshold(gray_img, 127, 255, cv2.THRESH_BINARY)
    kernel = np.ones((5, 5), np.uint8)
    erosion = cv2.erode(binary_img, kernel, iterations=1)
    # show("binary", erosion)
    contours, hierarchy = cv2.findContours(erosion, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    img1 = cv2.drawContours(img, contours, -1, (0, 0, 255), 2)
    # show("img1", img1)
    group = []
    for i in range(0, len(contours)):
        x, y, w, h = cv2.boundingRect(contours[i])
        if 10 < w < h and h > 30 and x > 50:
            group.append([x, y, w, h])
            new_img = cv2.rectangle(new_img, (x, y), (x + w, y + h), (0, 0, 255), 2)
    # show("img", new_img)
    return group


def get_contours_data(my_img):
    img_left = my_img[0:my_img.shape[0], 0:my_img.shape[1] - 45]
    img_left = cv2.copyMakeBorder(img_left, 0, 0, 0, my_img.shape[1] - img_left.shape[1],
                                  borderType=cv2.BORDER_CONSTANT, value=(255, 255, 255))
    img_right = my_img[0:my_img.shape[0], my_img.shape[1] - 40:my_img.shape[1]]
    img_right = cv2.copyMakeBorder(img_right, 0, 0, my_img.shape[1] - img_right.shape[1], 0,
                                   borderType=cv2.BORDER_CONSTANT, value=(255, 255, 255))
    left_contours = get_contours(img_left)
    right_contours = get_contours(img_right)
    all_contours = left_contours + right_contours
    return all_contours


def get_template(template_img, size):
    img = cv2.imread(template_img)
    # show('img', img)
    # 灰度图
    ref = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # show('ref', ref)
    # 二值图像
    binary = cv2.threshold(ref, 10, 255, cv2.THRESH_BINARY_INV)[1]
    # show('ref', ref)

    contours, hierarchy = cv2.findContours(binary.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    dataList = []
    number_images = []
    for i in range(0, len(contours)):
        x1, y1, w1, h1 = cv2.boundingRect(contours[i])
        img = cv2.rectangle(img, (x1, y1), (x1 + w1, y1 + h1), (0, 0, 255), 2)
        dataList.append([x1, y1, w1, h1])
    dataList = sorted(dataList, key=lambda lis: lis[0])
    for lis in dataList:
        temp = binary[lis[1] - 1:lis[1] + lis[3] + 1, lis[0] - 1:lis[0] + lis[2] + 1];
        tImg = cv2.resize(temp, size)
        number_images.append(tImg)
    return number_images


img = my_imread("../number_images/t2.png")
# show("imgaf",img)
position, new_img2 = get_num_img(img)
print(position)
my_img1 = cv2.resize(new_img2, (224, 60))
# show("myimg", my_img1)
all_contours = get_contours_data(my_img1)
for contour in all_contours:
    x, y, w, h = contour
    my_img = cv2.rectangle(my_img1, (x, y), (x + w, y + h), (0, 0, 255), 2)
# show("my_img", my_img1)

x, y, w, h = position
cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
# show("img", img)

# 计算缩放因子
kx = new_img2.shape[1] / 224
ky = new_img2.shape[0] / 60
# print(all_contours)
all_contours = sorted(all_contours, key=lambda lis: lis[0])
# print(all_contours)
# 计算数字区域
w = (all_contours[len(all_contours) - 1][0] - all_contours[0][0] + all_contours[len(all_contours) - 1][2]) * kx
h = (all_contours[len(all_contours) - 1][3]) * ky
x = (all_contours[0][0]) * kx + position[0]
y = (all_contours[0][1]) * ky + position[1]

# cv2.rectangle(img, (round(x), round(y)), (round(x + w), round(y + h)), (102, 174, 55), 2)
# show("img", img)

myImg = img[round(y):round(y + h), round(x):round(x + w)]
imgLen = (myImg.shape[1] - 10) / len(all_contours)
myImg = cv2.cvtColor(myImg, cv2.COLOR_BGR2GRAY)
myImg = cv2.threshold(myImg, 127, 255, cv2.THRESH_BINARY_INV)[1]
show("myImg", myImg)
target_images = []
eSize = (50, 80)
for i in range(1, len(all_contours)):
    # print(round(i * imgLen))
    sTemp = myImg[0:myImg.shape[0], round((i - 1) * imgLen):round(i * imgLen)]
    sImg = cv2.resize(sTemp, eSize)
    target_images.append(sImg)
sTemp = myImg[0:myImg.shape[0], round(myImg.shape[1] - imgLen):myImg.shape[1]]
sImg = cv2.resize(sTemp, eSize)
target_images.append(sImg)
template_images = get_template("../number_images/sss.png", eSize)
reading = ""
for i in range(0, len(target_images)):
    targetImg = target_images[i]
    scores = []
    show("targetImg", targetImg)
    for i in range(0, len(template_images)):
        templateImg = template_images[i]
        show("templateImg", templateImg)
        result = cv2.matchTemplate(targetImg, templateImg, cv2.TM_CCOEFF)
        (_, score, _, _) = cv2.minMaxLoc(result)
        print(score)
        scores.append(score)
    print(scores)
    reading = reading + str(np.argmax(scores))
print(reading)
