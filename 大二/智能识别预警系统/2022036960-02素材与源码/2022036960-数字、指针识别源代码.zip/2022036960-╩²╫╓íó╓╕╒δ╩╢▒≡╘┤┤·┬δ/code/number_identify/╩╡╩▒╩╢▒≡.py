import cv2
import numpy as np
import requests


def my_imread(src):
    return cv2.resize(cv2.imread(src), (500, 375))


def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    # cv2.destroyAllWindows()


def upload(source_img):
    # 请求地址
    url = 'http://localhost/upload'
    # 向files里传入图片
    files = {'image': open(source_img, "rb")}
    # 向data里传入id
    data = {
        "id": "1"
    }
    # 发送post请求
    r = requests.post(url, files=files, data=data)
    print(r.text)


def get_num_img(img):
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    kernel = np.ones((2, 2), np.uint8)
    img_blur2 = cv2.GaussianBlur(gray_img, (5, 5), 5)
    # show('blur',img_blur2)
    result, binary_img = cv2.threshold(img_blur2, 180, 255, cv2.THRESH_BINARY)
    # show("binary_img", binary_img)
    contours, hierarchy = cv2.findContours(binary_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    img1 = cv2.drawContours(img.copy(), contours, -1, (0, 0, 255), 1)
    # show("img1", img1)
    img = img.copy()
    new_img1 = img
    x2, y2, w2, h2 = 0, 0, 0, 0
    for i in range(0, len(contours)):
        x1, y1, w1, h1 = cv2.boundingRect(contours[i])
        if w1 > h1 * 3 and w1 > 100 and h1 > 30:
            print("进入了")
            new_img1 = img[y1:y1 + h1, x1:x1 + w1]
            x2, y2, w2, h2 = x1, y1, w1, h1
    xxx = cv2.rectangle(img, (x2, y2), (x2 + w2, y2 + h2), (0, 0, 255), 2)
    # show("xxx", xxx)
    return (x2, y2, w2, h2), new_img1


def get_contours(img):
    new_img = img.copy()
    gray_img = cv2.cvtColor(new_img, cv2.COLOR_BGR2GRAY)
    result, binary_img = cv2.threshold(gray_img, 220, 255, cv2.THRESH_BINARY)
    kernel = np.ones((5, 5), np.uint8)
    erosion = cv2.erode(binary_img, kernel, iterations=1)
    # show("binary", erosion)
    contours, hierarchy = cv2.findContours(erosion, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    img1 = cv2.drawContours(img, contours, -1, (0, 0, 255), 2)
    # show("img1", img1)
    group = []
    for i in range(0, len(contours)):
        x, y, w, h = cv2.boundingRect(contours[i])
        if 10 < w < h and h > 30 and x > 50:
            # print(x, y, w, h)
            if w < 15:
                w = w + 10
                x = x - 10
            group.append([x, y, w, h])
            new_img = cv2.rectangle(new_img, (x, y), (x + w, y + h), (0, 0, 255), 2)
    # show("img", new_img)
    return group


def get_contours_data(my_img):
    img_left = my_img[0:my_img.shape[0], 0:my_img.shape[1] - 45]
    img_left = cv2.copyMakeBorder(img_left, 0, 0, 0, my_img.shape[1] - img_left.shape[1],
                                  borderType=cv2.BORDER_CONSTANT, value=(255, 255, 255))
    img_right = my_img[0:my_img.shape[0], my_img.shape[1] - 40:my_img.shape[1]]
    img_right = cv2.copyMakeBorder(img_right, 0, 0, my_img.shape[1] - img_right.shape[1], 0,
                                   borderType=cv2.BORDER_CONSTANT, value=(255, 255, 255))
    # show("my_img",my_img)
    # show('left',img_left)
    # show('right',img_right)
    left_contours = get_contours(img_left)
    right_contours = get_contours(img_right)
    all_contours = left_contours + right_contours
    return all_contours


def get_template(size):
    number_images = []
    for i in range(0, 10):
        img = cv2.imread("../number_images/" + str(i) + ".png")
        ref = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # 二值图像
        binary = cv2.threshold(ref, 127, 255, cv2.THRESH_BINARY_INV)[1]
        # show('ref', ref)
        tImg = cv2.resize(binary, size)
        kernel = np.ones((3, 3), np.uint8)
        tImg = cv2.dilate(tImg, kernel, 1)
        number_images.append(tImg)
    return number_images


video = cv2.VideoCapture(1)
index = 1
# 判断视频视频是否能够打开
while video.isOpened():
    # 读取每一帧图片，第一个返回值为True或者False，表示是否读取成功，第二个就是读取的图像
    ret, frame = video.read()
    # 读取视频就退出循环
    if not ret:
        break
    # 展示每一帧图片

    # img = my_imread('../number_images/ok.png')
    img = cv2.resize(frame, (500, 375))
    try:
        # show("imgaf", img)
        position, new_img2 = get_num_img(img)
        # print(position)
        # show("new_img2", new_img2)
        my_img1 = cv2.resize(new_img2, (224, 60))
        # show("myimg", my_img1)
        all_contours = get_contours_data(my_img1)
        # for contour in all_contours:
        #     x, y, w, h = contour
        #     my_img = cv2.rectangle(my_img1, (x, y), (x + w, y + h), (0, 0, 255), 2)
        # show("my_img", my_img1)

        x, y, w, h = position
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
        # show("img", img)

        # 计算缩放因子
        kx = new_img2.shape[1] / 224
        ky = new_img2.shape[0] / 60
        # print(all_contours)
        all_contours = sorted(all_contours, key=lambda lis: lis[0])
        # print(all_contours)
        # 计算数字区域
        w = (all_contours[len(all_contours) - 1][0] - all_contours[0][0] + all_contours[len(all_contours) - 1][2]) * kx
        h = (all_contours[len(all_contours) - 1][3]) * ky
        x = (all_contours[0][0]) * kx + position[0]
        y = (all_contours[0][1]) * ky + position[1]

        cv2.rectangle(img, (round(x), round(y)), (round(x + w), round(y + h)), (102, 174, 55), 2)
        # show("img", img)

        myImg = img[round(y):round(y + h) - 4, round(x):round(x + w)]
        # show("myIng",myImg)
        imgLen = (myImg.shape[1]) / len(all_contours)
        my_img1 = cv2.cvtColor(my_img1, cv2.COLOR_BGR2GRAY)
        my_img1 = cv2.threshold(my_img1, 200, 255, cv2.THRESH_BINARY_INV)[1]
        # show("myImg", myImg)
        target_images = []
        eSize = (50, 80)
        # show("myimg1",my_img1)
        # my_img1 = cv2.cvtColor(my_img1, cv2.COLOR_BGR2GRAY)
        # my_img1 = cv2.threshold(my_img1, 127, 255, cv2.THRESH_BINARY)
        # show("myinfa",my_img1)
        for contour in all_contours:
            x, y, w, h = contour
            # print(x,y,w,h)
            sImg = my_img1[y:y + h, x:x + w]
            sImg = cv2.resize(sImg, eSize)
            kernel = np.ones((7, 7), np.uint8)
            sImg = cv2.dilate(sImg, kernel, 1)
            sImg = cv2.copyMakeBorder(sImg, 30, 30, 30, 30, borderType=cv2.BORDER_CONSTANT,
                                      value=0)
            target_images.append(sImg)

        template_images = get_template(eSize)

        reading = ""
        for j in range(0, len(target_images)):
            targetImg = target_images[j]
            scores = []
            # show("targetImg", targetImg)
            for i in range(0, len(template_images)):
                templateImg = template_images[i]
                # show("templateImg", templateImg)
                result = cv2.matchTemplate(targetImg, templateImg, cv2.TM_CCOEFF)
                (_, score, _, _) = cv2.minMaxLoc(result)
                if i == 7:
                    score = score * 0.8
                elif i == 1:
                    score = score * 0.8
                elif i == 0:
                    score = score * 1.4
                elif i == 8:
                    score = score * 0.9
                elif i == 3:
                    score = score * 0.9
                # print(score)
                scores.append(score)
            # print(scores)
            if j == len(target_images) - 1:
                reading = reading + "."
            reading = reading + str(np.argmax(scores))
        print(reading)
        img = cv2.putText(img, reading, (round(position[0]+65), round(position[1] + position[3]+30)),
                          cv2.FONT_HERSHEY_SIMPLEX, 1,
                          (0, 0, 255), 2)
        # show("end", img)
    except:
        print('异常')

    cv2.imshow("camera", img)
    # 等待10毫秒用户输入
    key = cv2.waitKey(10)
    # 输入q就退出循环
    if key & 0xFF == ord('q'):
        break

# 释放资源，关闭窗口
video.release()
cv2.destroyAllWindows()
