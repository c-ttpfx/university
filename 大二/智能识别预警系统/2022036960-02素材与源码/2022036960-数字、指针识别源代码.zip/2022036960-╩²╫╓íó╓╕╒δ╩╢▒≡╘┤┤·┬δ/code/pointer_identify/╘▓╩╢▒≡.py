import cv2
import numpy as np


def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


img = cv2.imread('../pointer_images/point_1.jpg')
img = cv2.resize(img, None, fx=0.5, fy=0.5)
show('img', img)
cimg = img.copy()
img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# img = cv2.medianBlur(img, 3)
show('img1', img)
ret, thread1 = cv2.threshold(img, 30, 255, cv2.THRESH_BINARY)
show('img2', thread1)
circles = cv2.HoughCircles(thread1, cv2.HOUGH_GRADIENT, 1, 10,
                           param1=50, param2=20, minRadius=0, maxRadius=20)
circles = np.uint16(np.around(circles))
for i in circles[0, :]:
    # 绘制外圈圆（蓝色）
    cv2.circle(cimg, (i[0], i[1]), i[2], (0, 255, 0), 2)

    # 绘制圆心（红色）
    cv2.circle(cimg, (i[0], i[1]), 2, (0, 0, 255), 3)

cv2.imshow('img3', cimg)
cv2.waitKey(0)
cv2.destroyAllWindows()
