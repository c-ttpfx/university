import cv2
import numpy as np


def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


img = cv2.imread('../pointer_images/1.png')
img = cv2.resize(img, (479, 636))
cimg = img.copy()
img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
img = cv2.medianBlur(img, 3)
show('img1', img)
ret, thread1 = cv2.threshold(img, 100, 127, cv2.THRESH_BINARY_INV)
show('img2', thread1)
blur = cv2.erode(thread1, (5, 5))
show('erode', blur)
edges = cv2.Canny(blur, 50, 150, apertureSize=3)
show('edge', edges)
