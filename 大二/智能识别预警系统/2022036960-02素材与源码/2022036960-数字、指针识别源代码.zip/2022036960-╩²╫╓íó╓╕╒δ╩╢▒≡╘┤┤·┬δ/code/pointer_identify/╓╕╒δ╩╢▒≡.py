import math

import cv2
import numpy as np


def show(name, img):
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def center_circle(img):
    cimg = img.copy()
    cimg = cv2.cvtColor(cimg, cv2.COLOR_BGR2GRAY)
    cimg = cv2.medianBlur(cimg, 3)
    # show('cimg1', cimg)
    ret, thread1 = cv2.threshold(cimg, 30, 255, cv2.THRESH_BINARY)
    # show('cimg2', thread1)
    circles = cv2.HoughCircles(thread1, cv2.HOUGH_GRADIENT, 1, 100, param1=100, param2=20, minRadius=0, maxRadius=20)
    circles = np.uint16(np.around(circles))
    for i in circles[0, :]:
        # 绘制外圈圆（蓝色）
        cv2.circle(img, (i[0], i[1]), i[2], (0, 255, 0), 2)
        print(i[2])
        # 绘制圆心（红色）
        cv2.circle(img, (i[0], i[1]), 2, (0, 0, 255), 3)
    # cv2.circle(img, (circles[0, 0][0], circles[0, 0][1]), circles[0, 0][2], (0, 255, 0), 2)
    # show('dasda', img)
    return circles[0, 0][0], circles[0, 0][1]


def angle(v1, v2):
    dx1 = v1[2] - v1[0]
    dy1 = v1[3] - v1[1]
    dx2 = v2[2] - v2[0]
    dy2 = v2[3] - v2[1]
    angle1 = math.atan2(dy1, dx1)
    angle1 = int(angle1 * 180 / math.pi)
    angle2 = math.atan2(dy2, dx2)
    angle2 = int(angle2 * 180 / math.pi)
    if angle1 * angle2 >= 0:
        included_angle = abs(angle1 - angle2)
    else:
        included_angle = abs(angle1) + abs(angle2)
        if included_angle > 180:
            included_angle = 360 - included_angle
    return included_angle


def getZero(source_img, template_img):
    source_img = cv2.cvtColor(source_img, cv2.COLOR_BGR2GRAY)
    template_img = cv2.cvtColor(template_img, cv2.COLOR_BGR2GRAY)
    res = cv2.matchTemplate(source_img, template_img, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
    return max_loc


def getK(line_, center_point):
    (x1_, y1_, x2_, y2_) = line_
    (center_point_x, center_point_y) = center_point
    x1_ -= center_point_x
    x2_ -= center_point_x
    y1_ -= center_point_y
    y2_ -= center_point_y
    y1_ = -y1_
    y2_ = -y2_
    print("x1 y1 x2 y2  ", x1_, y1_, x2_, y2_)
    return (y1_ - y2_) / (x1_ - x2_)


img = cv2.imread('../pointer_images/point_3.jpg')
print(img.shape)
template_img = cv2.imread('../pointer_images/zero.jpg')
zero_point = getZero(img, template_img)
print(zero_point)
coefficient = 0.7
img = cv2.resize(img, None, fx=coefficient, fy=coefficient)
cir_x, cir_y = center_circle(img)
print(cir_x/coefficient,cir_y/coefficient)
gimg = img.copy()
median_img = cv2.medianBlur(gimg, 5, 5)

# 灰度图 二值化
gray_img = cv2.cvtColor(median_img, cv2.COLOR_BGR2GRAY)

ret, thresh1 = cv2.threshold(gray_img, 65, 255, cv2.THRESH_BINARY)  # 小于70 黑 大于200白
# 边缘检测
test_main = thresh1.copy()
edges = cv2.Canny(test_main, 50, 150, apertureSize=3)
cv2.imshow('edges', edges)
lines = cv2.HoughLinesP(edges, 1, 1.0 * np.pi / 180, 50, minLineLength=120, maxLineGap=20)

start_x = int(zero_point[0] * coefficient)
start_y = int(zero_point[1] * coefficient + template_img.shape[1] * coefficient)
zero = (cir_x, cir_y, start_x, start_y)
# k_zero = angle(zero, (start_x, start_y, start_x, start_y))
print(lines)
# print('---------')
# 对直线进行排序
lines = sorted(lines, key=lambda l: abs(l[0][0] - l[0][2]) * abs(l[0][1] - l[0][3]))
print(lines)
for line in lines:

    # 选择第一条直线
    (x1, y1, x2, y2) = line[0]
    # cv2.line(img, (x1, y1), (x2, y2), (255, 0, 255), 2)  # 画直线

    if math.sqrt(abs(x1 - x2) ** 2 + abs(y1 - y2) ** 2) < 70:
        continue

    # 选择指针的结束点
    now = (cir_x, cir_y, x1, y1)
    print('直线：' + str(now))
    # 选择离圆心较远的点
    if (abs(x1 - cir_x) ** 2 + abs(y1 - cir_y) ** 2) < (abs(x2 - cir_x) ** 2 + abs(y2 - cir_y) ** 2):
        now = (cir_x, cir_y, x2, y2)
    print('变化直线：' + str(now))
    if math.sqrt(abs(now[0] - now[2]) ** 2 + abs(now[1] - now[3]) ** 2) > 150:
        continue
    degree = angle(zero, now)
    print("now：", getK(now, (cir_x, cir_y)))
    print("zero：", getK(zero, (start_x,start_y)))
    print('-------------',start_x,start_y)
    if now[2] > now[0] and getK(now, (cir_x, cir_y)) < getK(zero, (start_x,start_y)):
        degree = 360 - degree
    print('最终直线：' + str(now))
    print('角度差: ', degree)
    print('刻度为: ', degree / 360 * 1.4)
    cv2.putText(img, f'scale is {format(degree / 360 * 1.4, ".3f")}', (int(start_x * 1.2), start_y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65, (0, 0, 255), 2)
    cv2.line(img, (cir_x, cir_y), (now[2], now[3]), (0, 0, 255), 2)  # 画直线
    break
cv2.line(img, (start_x, start_y), (cir_x, cir_y), (0, 255, 255), 2)  # 画直线

show('img', img)
cv2.waitKey(0)
cv2.destroyAllWindows()
